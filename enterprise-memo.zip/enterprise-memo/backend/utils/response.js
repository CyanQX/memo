const success = (res, data = null, message = '操作成功', code = 200) => {
  return res.status(code).json({
    success: true,
    code,
    message,
    data,
    timestamp: Date.now(),
  });
};

const paginated = (res, data, pagination) => {
  return res.status(200).json({
    success: true,
    code: 200,
    message: '获取成功',
    data,
    pagination,
    timestamp: Date.now(),
  });
};

const error = (res, message = '操作失败', code = 500, errors = null) => {
  const body = {
    success: false,
    code,
    message,
    timestamp: Date.now(),
  };
  if (errors) body.errors = errors;
  return res.status(code).json(body);
};

const notFound = (res, message = '资源不存在') => error(res, message, 404);
const unauthorized = (res, message = '未授权，请先登录') => error(res, message, 401);
const forbidden = (res, message = '权限不足') => error(res, message, 403);
const badRequest = (res, message = '请求参数错误', errors = null) => error(res, message, 400, errors);

module.exports = { success, paginated, error, notFound, unauthorized, forbidden, badRequest };
