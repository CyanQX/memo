const Redis = require('ioredis');
const logger = require('../utils/logger');

const redis = new Redis({
  host: process.env.REDIS_HOST,
  port: parseInt(process.env.REDIS_PORT),
  password: process.env.REDIS_PASSWORD || undefined,
  db: parseInt(process.env.REDIS_DB) || 0,
  maxRetriesPerRequest: 3,
  enableReadyCheck: true,
  lazyConnect: false,
  keyPrefix: 'memo:',
});

redis.on('connect', () => {
  logger.info('Redis connected successfully');
});

redis.on('error', (err) => {
  logger.error('Redis error:', err.message);
});

redis.on('reconnecting', () => {
  logger.warn('Redis reconnecting...');
});

const CACHE_TTL = {
  USER: 3600,
  MEMO_LIST: 300,
  CATEGORY: 1800,
  STATS: 600,
};

module.exports = { redis, CACHE_TTL };
