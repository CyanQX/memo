const { verifyAccessToken } = require('../utils/jwt');
const { unauthorized, forbidden } = require('../utils/response');
const { redis } = require('../config/redis');
const { pool } = require('../config/database');
const logger = require('../utils/logger');

const authenticate = async (req, res, next) => {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return unauthorized(res);
    }

    const token = authHeader.split(' ')[1];

    const isBlacklisted = await redis.get(`blacklist:${token}`);
    if (isBlacklisted) {
      return unauthorized(res, 'Token已失效，请重新登录');
    }

    const decoded = verifyAccessToken(token);

    const [rows] = await pool.execute(
      'SELECT id, username, email, role, status FROM users WHERE id = ? AND status = 1',
      [decoded.userId]
    );

    if (!rows.length) {
      return unauthorized(res, '用户不存在或已被禁用');
    }

    req.user = rows[0];
    req.token = token;
    next();
  } catch (err) {
    logger.warn('Auth middleware error:', err.message);
    if (err.name === 'TokenExpiredError') {
      return unauthorized(res, 'Token已过期，请刷新');
    }
    return unauthorized(res, 'Token无效');
  }
};

const authorize = (...roles) => {
  return (req, res, next) => {
    if (!roles.includes(req.user.role)) {
      return forbidden(res, '您没有执行此操作的权限');
    }
    next();
  };
};

const optionalAuth = async (req, res, next) => {
  try {
    const authHeader = req.headers.authorization;
    if (authHeader && authHeader.startsWith('Bearer ')) {
      const token = authHeader.split(' ')[1];
      const decoded = verifyAccessToken(token);
      const [rows] = await pool.execute(
        'SELECT id, username, email, role FROM users WHERE id = ? AND status = 1',
        [decoded.userId]
      );
      if (rows.length) {
        req.user = rows[0];
      }
    }
  } catch {
    // Silent fail for optional auth
  }
  next();
};

module.exports = { authenticate, authorize, optionalAuth };
