const rateLimit = require('express-rate-limit');
const { error } = require('../utils/response');

const createLimiter = (windowMs, max, message) => {
  return rateLimit({
    windowMs,
    max,
    standardHeaders: true,
    legacyHeaders: false,
    handler: (req, res) => {
      return error(res, message, 429);
    },
  });
};

const globalLimiter = createLimiter(
  parseInt(process.env.RATE_LIMIT_WINDOW) || 900000,
  parseInt(process.env.RATE_LIMIT_MAX) || 200,
  '请求过于频繁，请稍后重试'
);

const authLimiter = createLimiter(900000, 10, '登录尝试过多，请15分钟后重试');

const uploadLimiter = createLimiter(60000, 5, '上传过于频繁，请1分钟后重试');

module.exports = { globalLimiter, authLimiter, uploadLimiter };
