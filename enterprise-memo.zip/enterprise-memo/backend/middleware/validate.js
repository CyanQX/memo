const Joi = require('joi');
const { badRequest } = require('../utils/response');

const validate = (schema, property = 'body') => {
  return (req, res, next) => {
    const { error, value } = schema.validate(req[property], {
      abortEarly: false,
      allowUnknown: false,
      stripUnknown: true,
    });

    if (error) {
      const errors = error.details.map((d) => ({
        field: d.path.join('.'),
        message: d.message.replace(/"/g, ''),
      }));
      return badRequest(res, '请求参数校验失败', errors);
    }

    req[property] = value;
    next();
  };
};

const schemas = {
  register: Joi.object({
    username: Joi.string().alphanum().min(3).max(50).required().messages({
      'string.alphanum': '用户名只能包含字母和数字',
      'string.min': '用户名至少3个字符',
      'string.max': '用户名最多50个字符',
      'any.required': '用户名不能为空',
    }),
    email: Joi.string().email().required().messages({
      'string.email': '邮箱格式不正确',
      'any.required': '邮箱不能为空',
    }),
    password: Joi.string()
      .min(8)
      .max(128)
      .pattern(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/)
      .required()
      .messages({
        'string.min': '密码至少8个字符',
        'string.pattern.base': '密码必须包含大小写字母和数字',
        'any.required': '密码不能为空',
      }),
    real_name: Joi.string().max(100).optional(),
    department: Joi.string().max(100).optional(),
  }),

  login: Joi.object({
    email: Joi.string().email().required(),
    password: Joi.string().required(),
  }),

  createMemo: Joi.object({
    title: Joi.string().min(1).max(255).required().messages({
      'any.required': '标题不能为空',
    }),
    content: Joi.string().max(100000).optional().allow(''),
    category_id: Joi.number().integer().positive().optional().allow(null),
    priority: Joi.string().valid('low', 'medium', 'high', 'urgent').default('medium'),
    is_pinned: Joi.number().valid(0, 1).default(0),
    tags: Joi.array().items(Joi.string().max(50)).max(10).optional(),
    reminder_at: Joi.date().iso().optional().allow(null),
  }),

  updateMemo: Joi.object({
    title: Joi.string().min(1).max(255).optional(),
    content: Joi.string().max(100000).optional().allow(''),
    category_id: Joi.number().integer().positive().optional().allow(null),
    priority: Joi.string().valid('low', 'medium', 'high', 'urgent').optional(),
    status: Joi.string().valid('active', 'archived', 'deleted').optional(),
    is_pinned: Joi.number().valid(0, 1).optional(),
    tags: Joi.array().items(Joi.string().max(50)).max(10).optional(),
    reminder_at: Joi.date().iso().optional().allow(null),
  }),

  createCategory: Joi.object({
    name: Joi.string().min(1).max(100).required(),
    color: Joi.string()
      .pattern(/^#[0-9A-Fa-f]{6}$/)
      .default('#007AFF'),
    icon: Joi.string().max(50).default('folder'),
    sort_order: Joi.number().integer().min(0).default(0),
  }),

  updateProfile: Joi.object({
    real_name: Joi.string().max(100).optional().allow(''),
    phone: Joi.string()
      .pattern(/^1[3-9]\d{9}$/)
      .optional()
      .allow('')
      .messages({ 'string.pattern.base': '手机号格式不正确' }),
    department: Joi.string().max(100).optional().allow(''),
  }),

  changePassword: Joi.object({
    old_password: Joi.string().required(),
    new_password: Joi.string()
      .min(8)
      .max(128)
      .pattern(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/)
      .required()
      .messages({ 'string.pattern.base': '新密码必须包含大小写字母和数字' }),
  }),

  queryMemos: Joi.object({
    page: Joi.number().integer().min(1).default(1),
    limit: Joi.number().integer().min(1).max(100).default(20),
    keyword: Joi.string().max(100).optional().allow(''),
    category_id: Joi.number().integer().positive().optional(),
    priority: Joi.string().valid('low', 'medium', 'high', 'urgent').optional(),
    status: Joi.string().valid('active', 'archived').default('active'),
    is_pinned: Joi.number().valid(0, 1).optional(),
    sort_by: Joi.string().valid('created_at', 'updated_at', 'title', 'priority').default('updated_at'),
    sort_order: Joi.string().valid('asc', 'desc').default('desc'),
  }),
};

module.exports = { validate, schemas };
