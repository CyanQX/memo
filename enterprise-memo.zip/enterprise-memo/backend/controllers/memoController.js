const { pool } = require('../config/database');
const { redis, CACHE_TTL } = require('../config/redis');
const { success, paginated, error, notFound, forbidden, badRequest } = require('../utils/response');
const logger = require('../utils/logger');
const { v4: uuidv4 } = require('uuid');

const buildMemoQuery = (userId, filters) => {
  const conditions = ['m.user_id = ?', 'm.status != "deleted"'];
  const params = [userId];

  if (filters.status) {
    conditions.push('m.status = ?');
    params.push(filters.status);
  }

  if (filters.category_id) {
    conditions.push('m.category_id = ?');
    params.push(parseInt(filters.category_id));
  }

  if (filters.priority) {
    conditions.push('m.priority = ?');
    params.push(filters.priority);
  }

  if (filters.is_pinned !== undefined) {
    conditions.push('m.is_pinned = ?');
    params.push(parseInt(filters.is_pinned));
  }

  if (filters.keyword) {
    conditions.push('(m.title LIKE ? OR m.content LIKE ?)');
    const kw = `%${filters.keyword}%`;
    params.push(kw, kw);
  }

  const sortMap = {
    created_at: 'm.created_at',
    updated_at: 'm.updated_at',
    title: 'm.title',
    priority: "FIELD(m.priority, 'urgent', 'high', 'medium', 'low')",
  };

  const sortCol = sortMap[filters.sort_by] || 'm.updated_at';
  const sortDir = filters.sort_order === 'asc' ? 'ASC' : 'DESC';

  const whereClause = conditions.join(' AND ');
  return { whereClause, params, sortCol, sortDir };
};

const getMemos = async (req, res) => {
  try {
    const { page, limit, ...filters } = req.query;
    const offset = (parseInt(page) - 1) * parseInt(limit);
    const { whereClause, params, sortCol, sortDir } = buildMemoQuery(req.user.id, filters);

    const countSql = `SELECT COUNT(*) as total FROM memos m WHERE ${whereClause}`;
    const [[{ total }]] = await pool.execute(countSql, params);

    const dataSql = `
      SELECT m.id, m.title, m.content, m.priority, m.status, m.is_pinned, m.is_shared,
             m.view_count, m.reminder_at, m.created_at, m.updated_at,
             c.id as category_id, c.name as category_name, c.color as category_color, c.icon as category_icon
      FROM memos m
      LEFT JOIN categories c ON m.category_id = c.id
      WHERE ${whereClause}
      ORDER BY m.is_pinned DESC, ${sortCol} ${sortDir}
      LIMIT ? OFFSET ?
    `;

    const [memos] = await pool.execute(dataSql, [...params, parseInt(limit), offset]);

    if (memos.length) {
      const memoIds = memos.map((m) => m.id);
      const placeholders = memoIds.map(() => '?').join(',');
      const [tags] = await pool.execute(
        `SELECT mt.memo_id, t.id, t.name FROM memo_tags mt JOIN tags t ON mt.tag_id = t.id WHERE mt.memo_id IN (${placeholders})`,
        memoIds
      );

      const tagMap = {};
      tags.forEach((t) => {
        if (!tagMap[t.memo_id]) tagMap[t.memo_id] = [];
        tagMap[t.memo_id].push({ id: t.id, name: t.name });
      });

      memos.forEach((m) => {
        m.tags = tagMap[m.id] || [];
        m.content_preview = m.content ? m.content.substring(0, 150) : '';
      });
    }

    return paginated(res, memos, {
      page: parseInt(page),
      limit: parseInt(limit),
      total: parseInt(total),
      total_pages: Math.ceil(total / parseInt(limit)),
    });
  } catch (err) {
    logger.error('Get memos error:', err);
    return error(res, '获取备忘录列表失败');
  }
};

const getMemoById = async (req, res) => {
  try {
    const { id } = req.params;

    const [rows] = await pool.execute(
      `SELECT m.*, c.name as category_name, c.color as category_color, c.icon as category_icon
       FROM memos m LEFT JOIN categories c ON m.category_id = c.id
       WHERE m.id = ? AND m.user_id = ? AND m.status != 'deleted'`,
      [id, req.user.id]
    );

    if (!rows.length) return notFound(res, '备忘录不存在');

    const memo = rows[0];

    const [tags] = await pool.execute(
      'SELECT t.id, t.name FROM memo_tags mt JOIN tags t ON mt.tag_id = t.id WHERE mt.memo_id = ?',
      [id]
    );
    memo.tags = tags;

    const [attachments] = await pool.execute(
      'SELECT id, original_name, file_type, file_size, url, created_at FROM attachments WHERE memo_id = ?',
      [id]
    );
    memo.attachments = attachments;

    await pool.execute('UPDATE memos SET view_count = view_count + 1 WHERE id = ?', [id]);

    return success(res, memo);
  } catch (err) {
    logger.error('Get memo error:', err);
    return error(res, '获取备忘录失败');
  }
};

const createMemo = async (req, res) => {
  const conn = await pool.getConnection();
  try {
    const { title, content, category_id, priority, is_pinned, tags, reminder_at } = req.body;
    const userId = req.user.id;

    if (category_id) {
      const [cat] = await conn.execute(
        'SELECT id FROM categories WHERE id = ? AND user_id = ?',
        [category_id, userId]
      );
      if (!cat.length) return badRequest(res, '分类不存在');
    }

    await conn.beginTransaction();

    const [result] = await conn.execute(
      'INSERT INTO memos (title, content, category_id, user_id, priority, is_pinned, reminder_at) VALUES (?, ?, ?, ?, ?, ?, ?)',
      [title, content || null, category_id || null, userId, priority, is_pinned || 0, reminder_at || null]
    );

    const memoId = result.insertId;

    if (tags && tags.length) {
      for (const tagName of tags) {
        const [existTag] = await conn.execute(
          'SELECT id FROM tags WHERE name = ? AND user_id = ?',
          [tagName, userId]
        );
        let tagId;
        if (existTag.length) {
          tagId = existTag[0].id;
        } else {
          const [tagResult] = await conn.execute(
            'INSERT INTO tags (name, user_id) VALUES (?, ?)',
            [tagName, userId]
          );
          tagId = tagResult.insertId;
        }
        await conn.execute('INSERT IGNORE INTO memo_tags (memo_id, tag_id) VALUES (?, ?)', [
          memoId,
          tagId,
        ]);
      }
    }

    await conn.commit();

    await redis.del(`memo:list:${userId}`);

    logger.info(`Memo created: ${memoId} by user ${userId}`);

    return success(res, { id: memoId, title }, '创建成功', 201);
  } catch (err) {
    await conn.rollback();
    logger.error('Create memo error:', err);
    return error(res, '创建备忘录失败');
  } finally {
    conn.release();
  }
};

const updateMemo = async (req, res) => {
  const conn = await pool.getConnection();
  try {
    const { id } = req.params;
    const userId = req.user.id;

    const [rows] = await conn.execute(
      "SELECT id FROM memos WHERE id = ? AND user_id = ? AND status != 'deleted'",
      [id, userId]
    );
    if (!rows.length) return notFound(res, '备忘录不存在');

    const { tags, ...fields } = req.body;

    const updateFields = [];
    const updateValues = [];

    const allowedFields = ['title', 'content', 'category_id', 'priority', 'status', 'is_pinned', 'is_shared', 'reminder_at'];
    allowedFields.forEach((field) => {
      if (fields[field] !== undefined) {
        updateFields.push(`${field} = ?`);
        updateValues.push(fields[field]);
      }
    });

    if (!updateFields.length && !tags) {
      return badRequest(res, '没有需要更新的字段');
    }

    await conn.beginTransaction();

    if (updateFields.length) {
      updateValues.push(id, userId);
      await conn.execute(
        `UPDATE memos SET ${updateFields.join(', ')} WHERE id = ? AND user_id = ?`,
        updateValues
      );
    }

    if (tags !== undefined) {
      await conn.execute('DELETE FROM memo_tags WHERE memo_id = ?', [id]);
      for (const tagName of tags) {
        const [existTag] = await conn.execute(
          'SELECT id FROM tags WHERE name = ? AND user_id = ?',
          [tagName, userId]
        );
        let tagId;
        if (existTag.length) {
          tagId = existTag[0].id;
        } else {
          const [tagResult] = await conn.execute(
            'INSERT INTO tags (name, user_id) VALUES (?, ?)',
            [tagName, userId]
          );
          tagId = tagResult.insertId;
        }
        await conn.execute('INSERT IGNORE INTO memo_tags (memo_id, tag_id) VALUES (?, ?)', [id, tagId]);
      }
    }

    await conn.commit();

    await redis.del(`memo:list:${userId}`);

    return success(res, null, '更新成功');
  } catch (err) {
    await conn.rollback();
    logger.error('Update memo error:', err);
    return error(res, '更新备忘录失败');
  } finally {
    conn.release();
  }
};

const deleteMemo = async (req, res) => {
  try {
    const { id } = req.params;
    const userId = req.user.id;
    const { permanent } = req.query;

    const [rows] = await pool.execute(
      'SELECT id FROM memos WHERE id = ? AND user_id = ?',
      [id, userId]
    );
    if (!rows.length) return notFound(res, '备忘录不存在');

    if (permanent === '1') {
      await pool.execute('DELETE FROM memos WHERE id = ? AND user_id = ?', [id, userId]);
    } else {
      await pool.execute(
        "UPDATE memos SET status = 'deleted' WHERE id = ? AND user_id = ?",
        [id, userId]
      );
    }

    await redis.del(`memo:list:${userId}`);

    return success(res, null, '删除成功');
  } catch (err) {
    logger.error('Delete memo error:', err);
    return error(res, '删除失败');
  }
};

const batchDelete = async (req, res) => {
  try {
    const { ids } = req.body;
    if (!ids || !ids.length) return badRequest(res, '请选择要删除的备忘录');

    const userId = req.user.id;
    const placeholders = ids.map(() => '?').join(',');

    await pool.execute(
      `UPDATE memos SET status = 'deleted' WHERE id IN (${placeholders}) AND user_id = ?`,
      [...ids, userId]
    );

    await redis.del(`memo:list:${userId}`);

    return success(res, null, `已删除 ${ids.length} 条备忘录`);
  } catch (err) {
    logger.error('Batch delete error:', err);
    return error(res, '批量删除失败');
  }
};

const getMemoStats = async (req, res) => {
  try {
    const userId = req.user.id;
    const cacheKey = `stats:${userId}`;
    const cached = await redis.get(cacheKey);
    if (cached) return success(res, JSON.parse(cached));

    const [total] = await pool.execute(
      "SELECT COUNT(*) as count FROM memos WHERE user_id = ? AND status != 'deleted'",
      [userId]
    );

    const [byPriority] = await pool.execute(
      "SELECT priority, COUNT(*) as count FROM memos WHERE user_id = ? AND status = 'active' GROUP BY priority",
      [userId]
    );

    const [byCategory] = await pool.execute(
      `SELECT c.name, c.color, COUNT(m.id) as count
       FROM categories c LEFT JOIN memos m ON c.id = m.category_id AND m.status = 'active'
       WHERE c.user_id = ? GROUP BY c.id`,
      [userId]
    );

    const [recentActivity] = await pool.execute(
      "SELECT DATE(created_at) as date, COUNT(*) as count FROM memos WHERE user_id = ? AND created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY) GROUP BY DATE(created_at) ORDER BY date",
      [userId]
    );

    const stats = {
      total: total[0].count,
      by_priority: byPriority,
      by_category: byCategory,
      recent_activity: recentActivity,
    };

    await redis.set(cacheKey, JSON.stringify(stats), 'EX', CACHE_TTL.STATS);

    return success(res, stats);
  } catch (err) {
    logger.error('Get stats error:', err);
    return error(res, '获取统计数据失败');
  }
};

module.exports = { getMemos, getMemoById, createMemo, updateMemo, deleteMemo, batchDelete, getMemoStats };
