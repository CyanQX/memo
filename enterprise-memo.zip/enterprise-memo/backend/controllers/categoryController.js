const { pool } = require('../config/database');
const { redis, CACHE_TTL } = require('../config/redis');
const { success, error, notFound, badRequest } = require('../utils/response');
const logger = require('../utils/logger');

const getCategories = async (req, res) => {
  try {
    const userId = req.user.id;
    const cacheKey = `categories:${userId}`;

    const cached = await redis.get(cacheKey);
    if (cached) return success(res, JSON.parse(cached));

    const [rows] = await pool.execute(
      `SELECT c.*, COUNT(m.id) as memo_count
       FROM categories c
       LEFT JOIN memos m ON c.id = m.category_id AND m.status = 'active'
       WHERE c.user_id = ?
       GROUP BY c.id
       ORDER BY c.sort_order ASC, c.created_at ASC`,
      [userId]
    );

    await redis.set(cacheKey, JSON.stringify(rows), 'EX', CACHE_TTL.CATEGORY);

    return success(res, rows);
  } catch (err) {
    logger.error('Get categories error:', err);
    return error(res, '获取分类失败');
  }
};

const createCategory = async (req, res) => {
  try {
    const { name, color, icon, sort_order } = req.body;
    const userId = req.user.id;

    const [existing] = await pool.execute(
      'SELECT id FROM categories WHERE name = ? AND user_id = ?',
      [name, userId]
    );
    if (existing.length) return badRequest(res, '该分类名称已存在');

    const [result] = await pool.execute(
      'INSERT INTO categories (name, color, icon, user_id, sort_order) VALUES (?, ?, ?, ?, ?)',
      [name, color, icon, userId, sort_order]
    );

    await redis.del(`categories:${userId}`);

    return success(res, { id: result.insertId, name, color, icon }, '创建成功', 201);
  } catch (err) {
    logger.error('Create category error:', err);
    return error(res, '创建分类失败');
  }
};

const updateCategory = async (req, res) => {
  try {
    const { id } = req.params;
    const userId = req.user.id;

    const [rows] = await pool.execute(
      'SELECT id FROM categories WHERE id = ? AND user_id = ?',
      [id, userId]
    );
    if (!rows.length) return notFound(res, '分类不存在');

    const { name, color, icon, sort_order } = req.body;
    const fields = [];
    const values = [];

    if (name) { fields.push('name = ?'); values.push(name); }
    if (color) { fields.push('color = ?'); values.push(color); }
    if (icon) { fields.push('icon = ?'); values.push(icon); }
    if (sort_order !== undefined) { fields.push('sort_order = ?'); values.push(sort_order); }

    if (!fields.length) return badRequest(res, '没有需要更新的字段');

    values.push(id, userId);
    await pool.execute(`UPDATE categories SET ${fields.join(', ')} WHERE id = ? AND user_id = ?`, values);

    await redis.del(`categories:${userId}`);

    return success(res, null, '更新成功');
  } catch (err) {
    logger.error('Update category error:', err);
    return error(res, '更新分类失败');
  }
};

const deleteCategory = async (req, res) => {
  try {
    const { id } = req.params;
    const userId = req.user.id;

    const [rows] = await pool.execute(
      'SELECT id FROM categories WHERE id = ? AND user_id = ?',
      [id, userId]
    );
    if (!rows.length) return notFound(res, '分类不存在');

    await pool.execute('UPDATE memos SET category_id = NULL WHERE category_id = ? AND user_id = ?', [id, userId]);
    await pool.execute('DELETE FROM categories WHERE id = ? AND user_id = ?', [id, userId]);

    await redis.del(`categories:${userId}`);

    return success(res, null, '删除成功');
  } catch (err) {
    logger.error('Delete category error:', err);
    return error(res, '删除分类失败');
  }
};

module.exports = { getCategories, createCategory, updateCategory, deleteCategory };
