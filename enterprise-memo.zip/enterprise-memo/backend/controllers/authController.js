const bcrypt = require('bcrypt');
const { pool } = require('../config/database');
const { redis } = require('../config/redis');
const { generateAccessToken, generateRefreshToken, verifyRefreshToken } = require('../utils/jwt');
const { success, error, badRequest, unauthorized } = require('../utils/response');
const logger = require('../utils/logger');

const SALT_ROUNDS = 12;

const register = async (req, res) => {
  const conn = await pool.getConnection();
  try {
    const { username, email, password, real_name, department } = req.body;

    const [existing] = await conn.execute(
      'SELECT id FROM users WHERE username = ? OR email = ? LIMIT 1',
      [username, email]
    );

    if (existing.length) {
      return badRequest(res, '用户名或邮箱已被注册');
    }

    const hashedPassword = await bcrypt.hash(password, SALT_ROUNDS);

    await conn.beginTransaction();

    const [result] = await conn.execute(
      'INSERT INTO users (username, email, password, real_name, department) VALUES (?, ?, ?, ?, ?)',
      [username, email, hashedPassword, real_name || null, department || null]
    );

    const userId = result.insertId;

    await conn.execute(
      "INSERT INTO categories (name, color, icon, user_id, sort_order) VALUES ('工作', '#007AFF', 'briefcase', ?, 1), ('个人', '#34C759', 'person', ?, 2), ('重要', '#FF3B30', 'star', ?, 3)",
      [userId, userId, userId]
    );

    await conn.commit();

    logger.info(`New user registered: ${username} (${email})`);

    return success(res, { id: userId, username, email }, '注册成功', 201);
  } catch (err) {
    await conn.rollback();
    logger.error('Register error:', err);
    return error(res, '注册失败，请稍后重试');
  } finally {
    conn.release();
  }
};

const login = async (req, res) => {
  try {
    const { email, password } = req.body;
    const clientIp = req.ip || req.connection.remoteAddress;
    const userAgent = req.headers['user-agent'] || '';

    const [rows] = await pool.execute(
      'SELECT id, username, email, password, role, status, real_name, department, avatar FROM users WHERE email = ? LIMIT 1',
      [email]
    );

    if (!rows.length) {
      return unauthorized(res, '邮箱或密码错误');
    }

    const user = rows[0];

    if (user.status === 0) {
      return unauthorized(res, '账号已被禁用，请联系管理员');
    }

    const passwordMatch = await bcrypt.compare(password, user.password);
    if (!passwordMatch) {
      return unauthorized(res, '邮箱或密码错误');
    }

    const tokenPayload = { userId: user.id, email: user.email, role: user.role };
    const accessToken = generateAccessToken(tokenPayload);
    const refreshToken = generateRefreshToken(tokenPayload);

    const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);
    await pool.execute(
      'INSERT INTO refresh_tokens (user_id, token, expires_at, device_info, ip_address) VALUES (?, ?, ?, ?, ?)',
      [user.id, refreshToken, expiresAt, userAgent.substring(0, 255), clientIp]
    );

    await pool.execute('UPDATE users SET last_login_at = NOW(), last_login_ip = ? WHERE id = ?', [
      clientIp,
      user.id,
    ]);

    delete user.password;

    logger.info(`User logged in: ${user.username}`);

    return success(res, {
      user,
      access_token: accessToken,
      refresh_token: refreshToken,
      token_type: 'Bearer',
      expires_in: 900,
    });
  } catch (err) {
    logger.error('Login error:', err);
    return error(res, '登录失败，请稍后重试');
  }
};

const refreshToken = async (req, res) => {
  try {
    const { refresh_token } = req.body;

    if (!refresh_token) {
      return badRequest(res, '缺少 refresh_token');
    }

    const decoded = verifyRefreshToken(refresh_token);

    const [rows] = await pool.execute(
      'SELECT id, user_id FROM refresh_tokens WHERE token = ? AND expires_at > NOW() LIMIT 1',
      [refresh_token]
    );

    if (!rows.length) {
      return unauthorized(res, 'refresh_token 无效或已过期');
    }

    const [users] = await pool.execute(
      'SELECT id, email, role FROM users WHERE id = ? AND status = 1',
      [decoded.userId]
    );

    if (!users.length) {
      return unauthorized(res, '用户不存在');
    }

    await pool.execute('DELETE FROM refresh_tokens WHERE id = ?', [rows[0].id]);

    const user = users[0];
    const tokenPayload = { userId: user.id, email: user.email, role: user.role };
    const newAccessToken = generateAccessToken(tokenPayload);
    const newRefreshToken = generateRefreshToken(tokenPayload);

    const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);
    await pool.execute(
      'INSERT INTO refresh_tokens (user_id, token, expires_at) VALUES (?, ?, ?)',
      [user.id, newRefreshToken, expiresAt]
    );

    return success(res, {
      access_token: newAccessToken,
      refresh_token: newRefreshToken,
      token_type: 'Bearer',
      expires_in: 900,
    });
  } catch (err) {
    logger.error('Refresh token error:', err);
    return unauthorized(res, 'Token刷新失败');
  }
};

const logout = async (req, res) => {
  try {
    const token = req.token;
    const decoded = require('../utils/jwt').decodeToken(token);
    const ttl = Math.max(0, decoded.exp - Math.floor(Date.now() / 1000));

    if (ttl > 0) {
      await redis.set(`blacklist:${token}`, '1', 'EX', ttl);
    }

    await pool.execute('DELETE FROM refresh_tokens WHERE user_id = ?', [req.user.id]);

    logger.info(`User logged out: ${req.user.username}`);

    return success(res, null, '退出登录成功');
  } catch (err) {
    logger.error('Logout error:', err);
    return error(res, '退出失败');
  }
};

const getProfile = async (req, res) => {
  try {
    const [rows] = await pool.execute(
      'SELECT id, username, email, real_name, phone, department, role, avatar, last_login_at, created_at FROM users WHERE id = ?',
      [req.user.id]
    );
    return success(res, rows[0]);
  } catch (err) {
    logger.error('Get profile error:', err);
    return error(res, '获取用户信息失败');
  }
};

module.exports = { register, login, refreshToken, logout, getProfile };
