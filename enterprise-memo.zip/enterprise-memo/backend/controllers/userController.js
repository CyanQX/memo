const bcrypt = require('bcrypt');
const path = require('path');
const fs = require('fs');
const multer = require('multer');
const { v4: uuidv4 } = require('uuid');
const { pool } = require('../config/database');
const { redis } = require('../config/redis');
const { success, error, badRequest, forbidden } = require('../utils/response');
const logger = require('../utils/logger');

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadDir = process.env.UPLOAD_DIR || './uploads';
    const avatarDir = path.join(uploadDir, 'avatars');
    if (!fs.existsSync(avatarDir)) fs.mkdirSync(avatarDir, { recursive: true });
    cb(null, avatarDir);
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    cb(null, `${uuidv4()}${ext}`);
  },
});

const upload = multer({
  storage,
  limits: { fileSize: 2 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const allowed = ['.jpg', '.jpeg', '.png', '.webp'];
    const ext = path.extname(file.originalname).toLowerCase();
    if (allowed.includes(ext)) {
      cb(null, true);
    } else {
      cb(new Error('只支持 JPG、PNG、WebP 格式'));
    }
  },
}).single('avatar');

const updateProfile = async (req, res) => {
  try {
    const { real_name, phone, department } = req.body;
    const userId = req.user.id;

    await pool.execute(
      'UPDATE users SET real_name = ?, phone = ?, department = ? WHERE id = ?',
      [real_name || null, phone || null, department || null, userId]
    );

    await redis.del(`user:${userId}`);

    return success(res, null, '个人信息更新成功');
  } catch (err) {
    logger.error('Update profile error:', err);
    return error(res, '更新失败');
  }
};

const changePassword = async (req, res) => {
  try {
    const { old_password, new_password } = req.body;
    const userId = req.user.id;

    const [rows] = await pool.execute('SELECT password FROM users WHERE id = ?', [userId]);
    const match = await bcrypt.compare(old_password, rows[0].password);

    if (!match) return forbidden(res, '原密码不正确');

    const hashed = await bcrypt.hash(new_password, 12);
    await pool.execute('UPDATE users SET password = ? WHERE id = ?', [hashed, userId]);

    await pool.execute('DELETE FROM refresh_tokens WHERE user_id = ?', [userId]);

    return success(res, null, '密码修改成功，请重新登录');
  } catch (err) {
    logger.error('Change password error:', err);
    return error(res, '修改密码失败');
  }
};

const uploadAvatar = (req, res) => {
  upload(req, res, async (uploadErr) => {
    if (uploadErr) {
      return badRequest(res, uploadErr.message || '文件上传失败');
    }

    if (!req.file) return badRequest(res, '请选择要上传的图片');

    try {
      const [rows] = await pool.execute('SELECT avatar FROM users WHERE id = ?', [req.user.id]);
      const oldAvatar = rows[0]?.avatar;

      const avatarUrl = `/uploads/avatars/${req.file.filename}`;

      await pool.execute('UPDATE users SET avatar = ? WHERE id = ?', [avatarUrl, req.user.id]);

      if (oldAvatar && oldAvatar.startsWith('/uploads/')) {
        const oldPath = path.join(process.env.UPLOAD_DIR || './uploads', oldAvatar.replace('/uploads/', ''));
        if (fs.existsSync(oldPath)) fs.unlinkSync(oldPath);
      }

      await redis.del(`user:${req.user.id}`);

      return success(res, { avatar_url: avatarUrl }, '头像上传成功');
    } catch (err) {
      logger.error('Upload avatar error:', err);
      return error(res, '头像保存失败');
    }
  });
};

const getUserList = async (req, res) => {
  try {
    const { page = 1, limit = 20, keyword, role, status } = req.query;
    const offset = (parseInt(page) - 1) * parseInt(limit);

    const conditions = ['1 = 1'];
    const params = [];

    if (keyword) {
      conditions.push('(username LIKE ? OR email LIKE ? OR real_name LIKE ?)');
      const kw = `%${keyword}%`;
      params.push(kw, kw, kw);
    }
    if (role) { conditions.push('role = ?'); params.push(role); }
    if (status !== undefined) { conditions.push('status = ?'); params.push(parseInt(status)); }

    const whereClause = conditions.join(' AND ');

    const [[{ total }]] = await pool.execute(`SELECT COUNT(*) as total FROM users WHERE ${whereClause}`, params);

    const [users] = await pool.execute(
      `SELECT id, username, email, real_name, department, role, status, last_login_at, created_at
       FROM users WHERE ${whereClause} ORDER BY created_at DESC LIMIT ? OFFSET ?`,
      [...params, parseInt(limit), offset]
    );

    return success(res, { list: users, pagination: { page: parseInt(page), limit: parseInt(limit), total } });
  } catch (err) {
    logger.error('Get user list error:', err);
    return error(res, '获取用户列表失败');
  }
};

const toggleUserStatus = async (req, res) => {
  try {
    const { id } = req.params;
    if (parseInt(id) === req.user.id) return forbidden(res, '不能禁用自己的账号');

    const [rows] = await pool.execute('SELECT status FROM users WHERE id = ?', [id]);
    if (!rows.length) return badRequest(res, '用户不存在');

    const newStatus = rows[0].status === 1 ? 0 : 1;
    await pool.execute('UPDATE users SET status = ? WHERE id = ?', [newStatus, id]);

    return success(res, { status: newStatus }, newStatus === 1 ? '账号已启用' : '账号已禁用');
  } catch (err) {
    logger.error('Toggle user status error:', err);
    return error(res, '操作失败');
  }
};

module.exports = { updateProfile, changePassword, uploadAvatar, getUserList, toggleUserStatus };
