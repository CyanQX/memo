require('dotenv').config();

const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const compression = require('compression');
const morgan = require('morgan');
const path = require('path');
const fs = require('fs');

const { testConnection } = require('./config/database');
const { redis } = require('./config/redis');
const logger = require('./utils/logger');
const { globalLimiter } = require('./middleware/rateLimiter');
const { error } = require('./utils/response');

const authRoutes = require('./routes/auth');
const memoRoutes = require('./routes/memo');
const categoryRoutes = require('./routes/category');
const userRoutes = require('./routes/user');

const app = express();
const PORT = process.env.PORT || 3000;

const uploadDir = process.env.UPLOAD_DIR || './uploads';
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true });

app.set('trust proxy', 1);

app.use(helmet({
  crossOriginResourcePolicy: { policy: 'cross-origin' },
}));

const allowedOrigins = (process.env.CORS_ORIGINS || '').split(',').filter(Boolean);
app.use(cors({
  origin: (origin, callback) => {
    if (!origin || allowedOrigins.includes(origin) || process.env.NODE_ENV === 'development') {
      callback(null, true);
    } else {
      callback(new Error('Not allowed by CORS'));
    }
  },
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization'],
}));

app.use(compression());
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

app.use(morgan('combined', {
  stream: { write: (msg) => logger.info(msg.trim()) },
}));

app.use(globalLimiter);

app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

app.get('/health', (req, res) => {
  res.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
    version: require('./package.json').version,
  });
});

app.use('/api/v1/auth', authRoutes);
app.use('/api/v1/memos', memoRoutes);
app.use('/api/v1/categories', categoryRoutes);
app.use('/api/v1/users', userRoutes);

app.use((req, res) => {
  return error(res, `接口不存在: ${req.method} ${req.path}`, 404);
});

app.use((err, req, res, next) => {
  logger.error('Unhandled error:', { message: err.message, stack: err.stack });
  if (err.message === 'Not allowed by CORS') {
    return error(res, 'CORS 错误', 403);
  }
  return error(res, process.env.NODE_ENV === 'production' ? '服务器内部错误' : err.message, 500);
});

const startServer = async () => {
  await testConnection();

  app.listen(PORT, '0.0.0.0', () => {
    logger.info(`🚀 Enterprise Memo API running on port ${PORT}`);
    logger.info(`📊 Environment: ${process.env.NODE_ENV}`);
    logger.info(`🏥 Health check: http://localhost:${PORT}/health`);
  });
};

process.on('SIGTERM', async () => {
  logger.info('SIGTERM received, shutting down gracefully');
  redis.disconnect();
  process.exit(0);
});

process.on('uncaughtException', (err) => {
  logger.error('Uncaught Exception:', err);
  process.exit(1);
});

process.on('unhandledRejection', (reason) => {
  logger.error('Unhandled Rejection:', reason);
});

startServer();
