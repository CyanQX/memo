const express = require('express');
const router = express.Router();
const { updateProfile, changePassword, uploadAvatar, getUserList, toggleUserStatus } = require('../controllers/userController');
const { authenticate, authorize } = require('../middleware/auth');
const { validate, schemas } = require('../middleware/validate');
const { uploadLimiter } = require('../middleware/rateLimiter');

router.use(authenticate);

router.put('/profile', validate(schemas.updateProfile), updateProfile);
router.put('/password', validate(schemas.changePassword), changePassword);
router.post('/avatar', uploadLimiter, uploadAvatar);

router.get('/list', authorize('super_admin', 'admin'), getUserList);
router.put('/:id/status', authorize('super_admin', 'admin'), toggleUserStatus);

module.exports = router;
