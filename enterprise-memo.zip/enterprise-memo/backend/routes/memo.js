const express = require('express');
const router = express.Router();
const {
  getMemos,
  getMemoById,
  createMemo,
  updateMemo,
  deleteMemo,
  batchDelete,
  getMemoStats,
} = require('../controllers/memoController');
const { authenticate } = require('../middleware/auth');
const { validate, schemas } = require('../middleware/validate');

router.use(authenticate);

router.get('/stats', getMemoStats);
router.get('/', validate(schemas.queryMemos, 'query'), getMemos);
router.get('/:id', getMemoById);
router.post('/', validate(schemas.createMemo), createMemo);
router.put('/:id', validate(schemas.updateMemo), updateMemo);
router.delete('/batch', batchDelete);
router.delete('/:id', deleteMemo);

module.exports = router;
