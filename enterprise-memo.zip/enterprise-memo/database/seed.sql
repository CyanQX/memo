USE enterprise_memo;

INSERT INTO users (username, email, password, real_name, department, role) VALUES
('admin', 'admin@company.com', '$2b$12$LQv3c1yqBWVHxkd0LHAkCOYz6TtxMQJqhN8/LewdBPj4J/HS.tYaS', '系统管理员', '信息技术部', 'super_admin');

INSERT INTO categories (name, color, icon, user_id, sort_order) VALUES
('工作', '#007AFF', 'briefcase', 1, 1),
('个人', '#34C759', 'person', 1, 2),
('重要', '#FF3B30', 'star', 1, 3),
('会议', '#FF9500', 'people', 1, 4);
