const BASE_URL = 'http://10.11.16.20:3000/api/v1';
const REQUEST_TIMEOUT = 15000;

let isRefreshing = false;
let pendingRequests = [];

const getToken = () => uni.getStorageSync('access_token');
const getRefreshToken = () => uni.getStorageSync('refresh_token');

const saveTokens = (accessToken, refreshToken) => {
  uni.setStorageSync('access_token', accessToken);
  if (refreshToken) uni.setStorageSync('refresh_token', refreshToken);
};

const clearAuth = () => {
  uni.removeStorageSync('access_token');
  uni.removeStorageSync('refresh_token');
  uni.removeStorageSync('user_info');
};

const doRefresh = () => {
  return new Promise((resolve, reject) => {
    const refreshToken = getRefreshToken();
    if (!refreshToken) {
      reject(new Error('no_refresh_token'));
      return;
    }
    uni.request({
      url: `${BASE_URL}/auth/refresh`,
      method: 'POST',
      data: { refresh_token: refreshToken },
      success: (res) => {
        if (res.statusCode === 200 && res.data.success) {
          saveTokens(res.data.data.access_token, res.data.data.refresh_token);
          resolve(res.data.data.access_token);
        } else {
          reject(new Error('refresh_failed'));
        }
      },
      fail: () => reject(new Error('network_error')),
    });
  });
};

const redirectToLogin = () => {
  clearAuth();
  uni.reLaunch({ url: '/pages/login/login' });
};

const request = (options) => {
  return new Promise((resolve, reject) => {
    const token = getToken();
    const header = {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...options.header,
    };

    uni.request({
      url: `${BASE_URL}${options.url}`,
      method: options.method || 'GET',
      data: options.data,
      header,
      timeout: REQUEST_TIMEOUT,
      success: async (res) => {
        if (res.statusCode === 401) {
          if (isRefreshing) {
            pendingRequests.push({ options, resolve, reject });
            return;
          }

          isRefreshing = true;
          try {
            const newToken = await doRefresh();
            isRefreshing = false;

            pendingRequests.forEach((pending) => {
              request(pending.options).then(pending.resolve).catch(pending.reject);
            });
            pendingRequests = [];

            const retryOptions = {
              ...options,
              header: { ...options.header, Authorization: `Bearer ${newToken}` },
            };
            const retryResult = await request(retryOptions);
            resolve(retryResult);
          } catch {
            isRefreshing = false;
            pendingRequests.forEach((p) => p.reject(new Error('unauthorized')));
            pendingRequests = [];
            redirectToLogin();
            reject(new Error('unauthorized'));
          }
          return;
        }

        if (res.statusCode >= 200 && res.statusCode < 300) {
          resolve(res.data);
        } else {
          const msg = res.data?.message || '请求失败';
          if (res.statusCode !== 401) {
            uni.showToast({ title: msg, icon: 'none', duration: 2000 });
          }
          reject({ code: res.statusCode, message: msg, data: res.data });
        }
      },
      fail: (err) => {
        uni.showToast({ title: '网络异常，请检查网络连接', icon: 'none' });
        reject(err);
      },
    });
  });
};

export const get = (url, params) =>
  request({ url: params ? `${url}?${new URLSearchParams(params)}` : url, method: 'GET' });

export const post = (url, data) => request({ url, method: 'POST', data });

export const put = (url, data) => request({ url, method: 'PUT', data });

export const del = (url, data) => request({ url, method: 'DELETE', data });

export default request;