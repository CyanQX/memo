import { get, post, put, del } from './request';

export const apiGetCategories = () => get('/categories');

export const apiCreateCategory = (data) => post('/categories', data);

export const apiUpdateCategory = (id, data) => put(`/categories/${id}`, data);

export const apiDeleteCategory = (id) => del(`/categories/${id}`);
