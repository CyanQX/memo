import { get, post } from './request';

export const apiRegister = (data) => post('/auth/register', data);

export const apiLogin = (data) => post('/auth/login', data);

export const apiLogout = () => post('/auth/logout');

export const apiRefreshToken = (data) => post('/auth/refresh', data);

export const apiGetProfile = () => get('/auth/profile');
