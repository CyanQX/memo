import { get, post, put, del } from './request';

export const apiGetMemos = (params) => get('/memos', params);

export const apiGetMemoById = (id) => get(`/memos/${id}`);

export const apiCreateMemo = (data) => post('/memos', data);

export const apiUpdateMemo = (id, data) => put(`/memos/${id}`, data);

export const apiDeleteMemo = (id, permanent = false) =>
  del(`/memos/${id}${permanent ? '?permanent=1' : ''}`);

export const apiBatchDeleteMemos = (ids) => del('/memos/batch', { ids });

export const apiGetMemoStats = () => get('/memos/stats');
