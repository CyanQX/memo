<script>
import { useUserStore } from './store/user';

export default {
  onLaunch() {
    const userStore = useUserStore();
    if (userStore.isLoggedIn) {
      userStore.fetchProfile();
    }
  },
  onShow() {},
  onHide() {},
};
</script>

<style>
page {
  background-color: #f4f6f9;
  font-family: -apple-system, 'PingFang SC', 'Helvetica Neue', sans-serif;
  font-size: 28rpx;
  color: #1c1c1e;
}

.safe-area-bottom {
  padding-bottom: constant(safe-area-inset-bottom);
  padding-bottom: env(safe-area-inset-bottom);
}

.container {
  min-height: 100vh;
  background-color: #f4f6f9;
}

button::after {
  border: none;
}
</style>
