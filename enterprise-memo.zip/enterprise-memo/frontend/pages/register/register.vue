<template>
  <view class="page">
    <view class="form-section">
      <view class="form-item" v-for="field in fields" :key="field.key">
        <view class="label">{{ field.label }}<text v-if="field.required" class="required">*</text></view>
        <input
          v-model="form[field.key]"
          class="input"
          :type="field.type || 'text'"
          :placeholder="field.placeholder"
          placeholder-class="placeholder"
        />
        <text v-if="errors[field.key]" class="error">{{ errors[field.key] }}</text>
      </view>

      <view class="form-item">
        <view class="label">密码强度</view>
        <view class="strength-bar">
          <view
            v-for="i in 4"
            :key="i"
            class="strength-item"
            :class="{ active: passwordStrength >= i, [`level-${passwordStrength}`]: passwordStrength >= i }"
          />
        </view>
        <text class="strength-label">{{ strengthLabel }}</text>
      </view>

      <button class="submit-btn" :loading="loading" @tap="handleRegister">创建账号</button>

      <view class="login-hint" @tap="goLogin">
        已有账号？<text class="link">立即登录</text>
      </view>
    </view>
  </view>
</template>

<script>
import { ref, reactive, computed } from 'vue';
import { apiRegister } from '../../api/auth';
import { showToast } from '../../utils/util';

export default {
  setup() {
    const loading = ref(false);
    const form = reactive({
      username: '',
      email: '',
      password: '',
      real_name: '',
      department: '',
    });
    const errors = reactive({});

    const fields = [
      { key: 'username', label: '用户名', placeholder: '3-50位字母或数字', required: true },
      { key: 'email', label: '邮箱', placeholder: '请输入企业邮箱', type: 'text', required: true },
      { key: 'password', label: '密码', placeholder: '8位以上，含大小写字母和数字', type: 'password', required: true },
      { key: 'real_name', label: '真实姓名', placeholder: '选填' },
      { key: 'department', label: '部门', placeholder: '选填' },
    ];

    const passwordStrength = computed(() => {
      const pwd = form.password;
      if (!pwd) return 0;
      let score = 0;
      if (pwd.length >= 8) score++;
      if (/[A-Z]/.test(pwd)) score++;
      if (/[0-9]/.test(pwd)) score++;
      if (/[^A-Za-z0-9]/.test(pwd)) score++;
      return score;
    });

    const strengthLabel = computed(() => {
      const map = { 0: '', 1: '弱', 2: '中等', 3: '强', 4: '非常强' };
      return map[passwordStrength.value];
    });

    const validate = () => {
      Object.keys(errors).forEach((k) => delete errors[k]);
      if (!form.username || form.username.length < 3) errors.username = '用户名至少3个字符';
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) errors.email = '请输入有效邮箱';
      if (!form.password || form.password.length < 8) errors.password = '密码至少8个字符';
      else if (!/(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/.test(form.password)) errors.password = '密码需包含大小写字母和数字';
      return !Object.keys(errors).length;
    };

    const handleRegister = async () => {
      if (!validate()) return;
      loading.value = true;
      try {
        const res = await apiRegister({
          username: form.username,
          email: form.email,
          password: form.password,
          real_name: form.real_name || undefined,
          department: form.department || undefined,
        });
        if (res.success) {
          showToast('注册成功，请登录', 'success');
          setTimeout(() => uni.navigateBack(), 1000);
        }
      } catch (err) {
        showToast(err?.message || '注册失败');
      } finally {
        loading.value = false;
      }
    };

    const goLogin = () => uni.navigateBack();

    return { form, errors, fields, loading, passwordStrength, strengthLabel, handleRegister, goLogin };
  },
};
</script>

<style scoped>
.page { background: #f4f6f9; min-height: 100vh; padding: 40rpx 40rpx 120rpx; }
.form-section { background: #fff; border-radius: 24rpx; padding: 48rpx 40rpx; box-shadow: 0 4rpx 20rpx rgba(0,0,0,0.06); }
.form-item { margin-bottom: 36rpx; }
.label { font-size: 28rpx; font-weight: 600; color: #3a3a3c; margin-bottom: 16rpx; }
.required { color: #ff3b30; margin-left: 4rpx; }
.input { width: 100%; height: 92rpx; background: #f4f6f9; border-radius: 16rpx; padding: 0 28rpx; font-size: 30rpx; color: #1c1c1e; }
.error { font-size: 24rpx; color: #ff3b30; margin-top: 8rpx; display: block; }
.placeholder { color: #c7c7cc; }
.strength-bar { display: flex; gap: 12rpx; margin-bottom: 12rpx; }
.strength-item { flex: 1; height: 8rpx; border-radius: 4rpx; background: #e5e5ea; }
.strength-item.active.level-1 { background: #ff3b30; }
.strength-item.active.level-2 { background: #ff9500; }
.strength-item.active.level-3 { background: #34c759; }
.strength-item.active.level-4 { background: #007aff; }
.strength-label { font-size: 24rpx; color: #8e8e93; }
.submit-btn { width: 100%; height: 100rpx; background: linear-gradient(135deg, #007aff, #0051d4); border-radius: 20rpx; font-size: 34rpx; font-weight: 700; color: #fff; margin-top: 20rpx; border: none; box-shadow: 0 8rpx 24rpx rgba(0,122,255,0.35); }
.login-hint { text-align: center; margin-top: 36rpx; font-size: 28rpx; color: #8e8e93; }
.link { color: #007aff; }
</style>
