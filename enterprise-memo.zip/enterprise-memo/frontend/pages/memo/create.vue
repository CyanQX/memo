<template>
  <view class="page">
    <view class="toolbar">
      <text class="cancel-btn" @tap="goBack">取消</text>
      <text class="toolbar-title">新建备忘录</text>
      <text class="save-btn" :class="{ disabled: !form.title }" @tap="handleSave">保存</text>
    </view>

    <scroll-view class="content-scroll" scroll-y>
      <view class="editor-area">
        <input
          v-model="form.title"
          class="title-input"
          placeholder="标题"
          placeholder-class="title-placeholder"
          maxlength="255"
        />

        <textarea
          v-model="form.content"
          class="content-textarea"
          placeholder="记录你的想法..."
          placeholder-class="placeholder"
          auto-height
          :maxlength="100000"
        />
      </view>

      <view class="meta-section">
        <view class="meta-item" @tap="showCategoryPicker = true">
          <view class="meta-left">
            <text class="meta-icon">📁</text>
            <text class="meta-label">分类</text>
          </view>
          <view class="meta-right">
            <text class="meta-value" :style="{ color: selectedCategory?.color || '#c7c7cc' }">
              {{ selectedCategory?.name || '未分类' }}
            </text>
            <text class="meta-arrow">›</text>
          </view>
        </view>

        <view class="meta-item" @tap="showPriorityPicker = true">
          <view class="meta-left">
            <text class="meta-icon">🎯</text>
            <text class="meta-label">优先级</text>
          </view>
          <view class="meta-right">
            <view class="priority-dot" :style="{ backgroundColor: PRIORITY_MAP[form.priority]?.color }" />
            <text class="meta-value">{{ PRIORITY_MAP[form.priority]?.label }}</text>
            <text class="meta-arrow">›</text>
          </view>
        </view>

        <view class="meta-item" @tap="showReminderPicker = true">
          <view class="meta-left">
            <text class="meta-icon">⏰</text>
            <text class="meta-label">提醒</text>
          </view>
          <view class="meta-right">
            <text class="meta-value">{{ form.reminder_at ? formatDate(form.reminder_at, 'MM-DD HH:mm') : '无' }}</text>
            <text class="meta-arrow">›</text>
          </view>
        </view>

        <view class="meta-item">
          <view class="meta-left">
            <text class="meta-icon">📌</text>
            <text class="meta-label">置顶</text>
          </view>
          <switch :checked="form.is_pinned === 1" color="#007aff" @change="form.is_pinned = $event.detail.value ? 1 : 0" />
        </view>

        <view class="tags-section">
          <view class="meta-left">
            <text class="meta-icon">🏷️</text>
            <text class="meta-label">标签</text>
          </view>
          <view class="tags-wrap">
            <view v-for="(tag, idx) in form.tags" :key="idx" class="tag-chip">
              <text>{{ tag }}</text>
              <text class="tag-remove" @tap="removeTag(idx)">×</text>
            </view>
            <view v-if="form.tags.length < 10" class="tag-add" @tap="addTag">
              + 添加
            </view>
          </view>
        </view>
      </view>

      <view style="height: 100rpx" />
    </scroll-view>

    <uni-popup ref="categoryPickerRef" type="bottom">
      <view class="picker-sheet">
        <view class="picker-header">
          <text>选择分类</text>
          <text class="picker-close" @tap="categoryPickerRef.close()">✕</text>
        </view>
        <view
          v-for="cat in [{ id: null, name: '未分类', color: '#8e8e93' }, ...memoStore.categories]"
          :key="cat.id"
          class="picker-item"
          :class="{ active: form.category_id === cat.id }"
          @tap="selectCategory(cat)"
        >
          <view class="cat-dot" :style="{ backgroundColor: cat.color }" />
          <text>{{ cat.name }}</text>
          <text v-if="form.category_id === cat.id" class="check-mark">✓</text>
        </view>
      </view>
    </uni-popup>

    <uni-popup ref="priorityPickerRef" type="bottom">
      <view class="picker-sheet">
        <view class="picker-header">
          <text>选择优先级</text>
          <text class="picker-close" @tap="priorityPickerRef.close()">✕</text>
        </view>
        <view
          v-for="(p, key) in PRIORITY_MAP"
          :key="key"
          class="picker-item"
          @tap="selectPriority(key)"
        >
          <view class="priority-dot-lg" :style="{ backgroundColor: p.color }" />
          <text>{{ p.label }}</text>
          <text v-if="form.priority === key" class="check-mark">✓</text>
        </view>
      </view>
    </uni-popup>
  </view>
</template>

<script>
import { ref, reactive, computed } from 'vue';
import { useMemoStore } from '../../store/memo';
import { apiCreateMemo } from '../../api/memo';
import { PRIORITY_MAP, formatDate, showToast } from '../../utils/util';

export default {
  setup() {
    const memoStore = useMemoStore();
    const loading = ref(false);
    const showCategoryPicker = ref(false);
    const showPriorityPicker = ref(false);
    const showReminderPicker = ref(false);
    const categoryPickerRef = ref(null);
    const priorityPickerRef = ref(null);

    const form = reactive({
      title: '',
      content: '',
      category_id: null,
      priority: 'medium',
      is_pinned: 0,
      tags: [],
      reminder_at: null,
    });

    const selectedCategory = computed(() =>
      form.category_id ? memoStore.categories.find((c) => c.id === form.category_id) : null
    );

    const selectCategory = (cat) => {
      form.category_id = cat.id;
      categoryPickerRef.value?.close();
    };

    const selectPriority = (key) => {
      form.priority = key;
      priorityPickerRef.value?.close();
    };

    const addTag = () => {
      uni.showModal({
        title: '添加标签',
        editable: true,
        placeholderText: '请输入标签名',
        success: (res) => {
          if (res.confirm && res.content?.trim()) {
            const tag = res.content.trim();
            if (!form.tags.includes(tag)) form.tags.push(tag);
          }
        },
      });
    };

    const removeTag = (idx) => form.tags.splice(idx, 1);

    const goBack = () => uni.navigateBack();

    const handleSave = async () => {
      if (!form.title.trim()) return showToast('标题不能为空');
      if (loading.value) return;
      loading.value = true;
      try {
        const res = await apiCreateMemo({
          title: form.title.trim(),
          content: form.content,
          category_id: form.category_id,
          priority: form.priority,
          is_pinned: form.is_pinned,
          tags: form.tags,
          reminder_at: form.reminder_at,
        });
        if (res.success) {
          showToast('创建成功', 'success');
          memoStore.fetchMemos(1);
          setTimeout(() => uni.navigateBack(), 300);
        }
      } catch (err) {
        showToast(err?.message || '创建失败');
      } finally {
        loading.value = false;
      }
    };

    return {
      form, memoStore, loading, selectedCategory, PRIORITY_MAP,
      showCategoryPicker, showPriorityPicker, showReminderPicker,
      categoryPickerRef, priorityPickerRef,
      selectCategory, selectPriority, addTag, removeTag, goBack, handleSave, formatDate,
    };
  },
};
</script>

<style scoped>
.page { min-height: 100vh; background: #f4f6f9; }

.toolbar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 100rpx 40rpx 28rpx;
  background: #fff;
  border-bottom: 1rpx solid #f0f0f0;
}

.cancel-btn { font-size: 32rpx; color: #8e8e93; }
.toolbar-title { font-size: 34rpx; font-weight: 600; color: #1c1c1e; }
.save-btn { font-size: 32rpx; color: #007aff; font-weight: 600; }
.save-btn.disabled { color: #c7c7cc; }

.content-scroll { height: calc(100vh - 180rpx); }

.editor-area {
  background: #fff;
  padding: 40rpx;
  margin-bottom: 20rpx;
}

.title-input {
  width: 100%;
  font-size: 44rpx;
  font-weight: 700;
  color: #1c1c1e;
  margin-bottom: 28rpx;
}

.title-placeholder { color: #c7c7cc; font-weight: 700; }

.content-textarea {
  width: 100%;
  font-size: 30rpx;
  color: #3a3a3c;
  line-height: 1.7;
  min-height: 240rpx;
}

.placeholder { color: #c7c7cc; }

.meta-section { background: #fff; }

.meta-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 32rpx 40rpx;
  border-bottom: 1rpx solid #f0f0f0;
}

.meta-left { display: flex; align-items: center; gap: 20rpx; }
.meta-icon { font-size: 34rpx; }
.meta-label { font-size: 30rpx; color: #1c1c1e; }
.meta-right { display: flex; align-items: center; gap: 12rpx; }
.meta-value { font-size: 28rpx; color: #8e8e93; }
.meta-arrow { font-size: 36rpx; color: #c7c7cc; }

.priority-dot { width: 20rpx; height: 20rpx; border-radius: 50%; }

.tags-section {
  padding: 28rpx 40rpx;
  display: flex;
  flex-direction: column;
  gap: 20rpx;
}

.tags-wrap { display: flex; flex-wrap: wrap; gap: 16rpx; }

.tag-chip {
  display: flex;
  align-items: center;
  background: #e8f4fe;
  color: #007aff;
  border-radius: 20rpx;
  padding: 10rpx 20rpx;
  font-size: 26rpx;
  gap: 10rpx;
}

.tag-remove { font-size: 28rpx; color: #007aff; }

.tag-add {
  padding: 10rpx 24rpx;
  border: 2rpx dashed #c7c7cc;
  border-radius: 20rpx;
  font-size: 26rpx;
  color: #8e8e93;
}

.picker-sheet {
  background: #fff;
  border-radius: 32rpx 32rpx 0 0;
  padding: 0 0 calc(40rpx + env(safe-area-inset-bottom));
  min-height: 400rpx;
}

.picker-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 40rpx 40rpx 24rpx;
  font-size: 32rpx;
  font-weight: 600;
  border-bottom: 1rpx solid #f0f0f0;
}

.picker-close { color: #8e8e93; font-size: 36rpx; }

.picker-item {
  display: flex;
  align-items: center;
  gap: 24rpx;
  padding: 32rpx 40rpx;
  font-size: 32rpx;
  color: #1c1c1e;
  border-bottom: 1rpx solid #f9f9f9;
}

.picker-item.active { background: #f0f7ff; }
.cat-dot { width: 24rpx; height: 24rpx; border-radius: 50%; }
.priority-dot-lg { width: 28rpx; height: 28rpx; border-radius: 50%; }
.check-mark { margin-left: auto; color: #007aff; font-weight: 700; }
</style>
