<template>
  <view class="page" v-if="memo">
    <view class="detail-header" :style="{ borderTopColor: priorityColor }">
      <view class="header-meta">
        <view class="priority-tag" :style="{ backgroundColor: priorityColor + '20', color: priorityColor }">
          {{ PRIORITY_MAP[memo.priority]?.label }}
        </view>
        <view v-if="memo.is_pinned" class="pin-tag">📌 已置顶</view>
        <view v-if="memo.category_name" class="cat-tag" :style="{ color: memo.category_color }">
          {{ memo.category_name }}
        </view>
      </view>

      <text class="detail-title">{{ memo.title }}</text>

      <view class="detail-time">
        <text>创建于 {{ formatDate(memo.created_at, 'YYYY-MM-DD HH:mm') }}</text>
        <text v-if="memo.updated_at !== memo.created_at">
          · 更新于 {{ formatDate(memo.updated_at) }}
        </text>
      </view>
    </view>

    <scroll-view class="detail-scroll" scroll-y>
      <view class="detail-body">
        <text class="detail-content" v-if="memo.content">{{ memo.content }}</text>
        <text v-else class="empty-content">暂无内容</text>
      </view>

      <view v-if="memo.tags && memo.tags.length" class="tags-section">
        <text class="section-title">标签</text>
        <view class="tags-row">
          <text v-for="tag in memo.tags" :key="tag.id" class="tag-chip">#{{ tag.name }}</text>
        </view>
      </view>

      <view v-if="memo.reminder_at" class="reminder-box">
        <text class="reminder-icon">⏰</text>
        <text class="reminder-text">提醒：{{ formatDate(memo.reminder_at, 'YYYY-MM-DD HH:mm') }}</text>
      </view>

      <view style="height: 200rpx" />
    </scroll-view>

    <view class="bottom-bar safe-area-bottom">
      <view class="bar-btn" @tap="goEdit">
        <text class="bar-icon">✏️</text>
        <text class="bar-label">编辑</text>
      </view>
      <view class="bar-btn" @tap="togglePin">
        <text class="bar-icon">{{ memo.is_pinned ? '📌' : '📍' }}</text>
        <text class="bar-label">{{ memo.is_pinned ? '取消置顶' : '置顶' }}</text>
      </view>
      <view class="bar-btn" @tap="confirmDelete">
        <text class="bar-icon">🗑️</text>
        <text class="bar-label danger">删除</text>
      </view>
    </view>
  </view>

  <view v-else class="loading-page">
    <view class="loading-spinner" />
  </view>
</template>

<script>
import { ref, computed, onMounted } from 'vue';
import { apiGetMemoById, apiUpdateMemo, apiDeleteMemo } from '../../api/memo';
import { useMemoStore } from '../../store/memo';
import { PRIORITY_MAP, formatDate, showToast, showModal } from '../../utils/util';

export default {
  setup() {
    const memoStore = useMemoStore();
    const memo = ref(null);
    const memoId = ref(null);

    const priorityColor = computed(() => PRIORITY_MAP[memo.value?.priority]?.color || '#8e8e93');

    const loadMemo = async () => {
      const pages = getCurrentPages();
      const currentPage = pages[pages.length - 1];
      memoId.value = currentPage.options?.id;
      if (!memoId.value) return;

      try {
        const res = await apiGetMemoById(memoId.value);
        if (res.success) memo.value = res.data;
      } catch {
        showToast('获取备忘录失败');
        uni.navigateBack();
      }
    };

    const goEdit = () => uni.navigateTo({ url: `/pages/memo/edit?id=${memoId.value}` });

    const togglePin = async () => {
      const newPin = memo.value.is_pinned ? 0 : 1;
      try {
        await apiUpdateMemo(memoId.value, { is_pinned: newPin });
        memo.value.is_pinned = newPin;
        memoStore.updateMemoInList(parseInt(memoId.value), { is_pinned: newPin });
        showToast(newPin ? '已置顶' : '已取消置顶');
      } catch {}
    };

    const confirmDelete = async () => {
      const ok = await showModal('确认删除', '确定要删除此备忘录吗？');
      if (!ok) return;
      try {
        await apiDeleteMemo(memoId.value);
        memoStore.memos = memoStore.memos.filter((m) => m.id !== parseInt(memoId.value));
        showToast('已删除');
        setTimeout(() => uni.navigateBack(), 500);
      } catch {}
    };

    onMounted(loadMemo);

    return { memo, priorityColor, PRIORITY_MAP, formatDate, goEdit, togglePin, confirmDelete };
  },
};
</script>

<style scoped>
.page { min-height: 100vh; background: #f4f6f9; }

.detail-header {
  background: #fff;
  padding: 40rpx 40rpx 32rpx;
  border-top: 6rpx solid #007aff;
  margin-bottom: 20rpx;
}

.header-meta { display: flex; align-items: center; gap: 16rpx; flex-wrap: wrap; margin-bottom: 24rpx; }

.priority-tag, .pin-tag, .cat-tag {
  font-size: 22rpx;
  font-weight: 600;
  padding: 6rpx 20rpx;
  border-radius: 20rpx;
}

.pin-tag { background: #fff3e0; color: #ff9500; }
.cat-tag { background: currentColor; opacity: 0.85; }

.detail-title {
  font-size: 44rpx;
  font-weight: 700;
  color: #1c1c1e;
  line-height: 1.4;
  display: block;
  margin-bottom: 20rpx;
}

.detail-time { font-size: 24rpx; color: #c7c7cc; }

.detail-scroll { height: calc(100vh - 360rpx); }

.detail-body {
  background: #fff;
  padding: 40rpx;
  margin-bottom: 20rpx;
  min-height: 200rpx;
}

.detail-content {
  font-size: 30rpx;
  color: #3a3a3c;
  line-height: 1.8;
  white-space: pre-wrap;
}

.empty-content { font-size: 30rpx; color: #c7c7cc; }

.tags-section {
  background: #fff;
  padding: 32rpx 40rpx;
  margin-bottom: 20rpx;
}

.section-title { font-size: 26rpx; color: #8e8e93; font-weight: 600; display: block; margin-bottom: 20rpx; }

.tags-row { display: flex; flex-wrap: wrap; gap: 16rpx; }

.tag-chip {
  background: #e8f4fe;
  color: #007aff;
  font-size: 26rpx;
  padding: 8rpx 20rpx;
  border-radius: 20rpx;
}

.reminder-box {
  background: #fff8e1;
  margin: 0 0 20rpx;
  padding: 28rpx 40rpx;
  display: flex;
  align-items: center;
  gap: 16rpx;
}

.reminder-icon { font-size: 32rpx; }
.reminder-text { font-size: 28rpx; color: #e65100; }

.bottom-bar {
  position: fixed;
  bottom: 0;
  left: 0;
  right: 0;
  background: #fff;
  border-top: 1rpx solid #f0f0f0;
  display: flex;
  padding: 24rpx 0;
}

.bar-btn {
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 8rpx;
}

.bar-icon { font-size: 36rpx; }
.bar-label { font-size: 24rpx; color: #636366; }
.bar-label.danger { color: #ff3b30; }

.loading-page {
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
}

.loading-spinner {
  width: 80rpx;
  height: 80rpx;
  border: 6rpx solid #e5e5ea;
  border-top-color: #007aff;
  border-radius: 50%;
  animation: spin 0.8s linear infinite;
}

@keyframes spin { to { transform: rotate(360deg); } }
</style>
