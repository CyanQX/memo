<template>
  <view class="page">
    <view class="profile-header">
      <view class="avatar-wrap" @tap="uploadAvatar">
        <image v-if="userStore.avatar" :src="serverUrl + userStore.avatar" class="avatar" mode="aspectFill" />
        <view v-else class="avatar-placeholder">
          <text class="avatar-letter">{{ avatarLetter }}</text>
        </view>
        <view class="avatar-edit">📷</view>
      </view>
      <text class="profile-name">{{ userStore.userInfo?.real_name || userStore.username }}</text>
      <text class="profile-email">{{ userStore.userInfo?.email }}</text>
      <view class="role-badge">{{ ROLE_MAP[userStore.role] || '用户' }}</view>
    </view>

    <view v-if="memoStore.stats" class="stats-row">
      <view class="stat-item">
        <text class="stat-num">{{ memoStore.stats.total }}</text>
        <text class="stat-label">总备忘录</text>
      </view>
      <view class="stat-divider" />
      <view class="stat-item">
        <text class="stat-num urgent">{{ urgentCount }}</text>
        <text class="stat-label">紧急</text>
      </view>
      <view class="stat-divider" />
      <view class="stat-item">
        <text class="stat-num">{{ memoStore.categories.length }}</text>
        <text class="stat-label">分类</text>
      </view>
    </view>

    <view class="section">
      <view class="section-title">个人设置</view>
      <view class="menu-list">
        <view class="menu-item" @tap="goEditProfile">
          <text class="menu-icon">👤</text>
          <text class="menu-label">编辑个人信息</text>
          <text class="menu-arrow">›</text>
        </view>
        <view class="menu-item" @tap="goChangePassword">
          <text class="menu-icon">🔐</text>
          <text class="menu-label">修改密码</text>
          <text class="menu-arrow">›</text>
        </view>
        <view class="menu-item" @tap="goManageCategories">
          <text class="menu-icon">📁</text>
          <text class="menu-label">管理分类</text>
          <text class="menu-arrow">›</text>
        </view>
      </view>
    </view>

    <view class="section">
      <view class="section-title">其他</view>
      <view class="menu-list">
        <view class="menu-item" @tap="showAbout">
          <text class="menu-icon">ℹ️</text>
          <text class="menu-label">关于应用</text>
          <text class="menu-version">v1.0.0</text>
        </view>
      </view>
    </view>

    <view class="logout-wrap">
      <button class="logout-btn" @tap="handleLogout">退出登录</button>
    </view>
  </view>
</template>

<script>
import { ref, computed, onMounted } from 'vue';
import { useUserStore } from '../../store/user';
import { useMemoStore } from '../../store/memo';
import { ROLE_MAP, showToast, showModal } from '../../utils/util';

const SERVER_URL = 'https://api.yourdomain.com';

export default {
  setup() {
    const userStore = useUserStore();
    const memoStore = useMemoStore();

    const avatarLetter = computed(() => {
      const name = userStore.userInfo?.real_name || userStore.username || '';
      return name.charAt(0).toUpperCase();
    });

    const urgentCount = computed(() => {
      const item = memoStore.stats?.by_priority?.find((p) => p.priority === 'urgent');
      return item?.count || 0;
    });

    const uploadAvatar = () => {
      uni.chooseImage({
        count: 1,
        sizeType: ['compressed'],
        sourceType: ['album', 'camera'],
        success: (res) => {
          const filePath = res.tempFilePaths[0];
          uni.uploadFile({
            url: `${SERVER_URL}/api/v1/users/avatar`,
            filePath,
            name: 'avatar',
            header: { Authorization: `Bearer ${uni.getStorageSync('access_token')}` },
            success: (uploadRes) => {
              const data = JSON.parse(uploadRes.data);
              if (data.success) {
                userStore.setUserInfo({ ...userStore.userInfo, avatar: data.data.avatar_url });
                showToast('头像更新成功', 'success');
              }
            },
          });
        },
      });
    };

    const goEditProfile = () => uni.navigateTo({ url: '/pages/profile/editProfile' });
    const goChangePassword = () => uni.navigateTo({ url: '/pages/profile/changePassword' });
    const goManageCategories = () => uni.navigateTo({ url: '/pages/profile/categories' });

    const showAbout = () => {
      uni.showModal({ title: '企业备忘录', content: '版本 v1.0.0\n企业级备忘录管理系统\n© 2025 Your Company', showCancel: false });
    };

    const handleLogout = async () => {
      const ok = await showModal('退出确认', '确定要退出登录吗？');
      if (!ok) return;
      await userStore.logout();
      uni.reLaunch({ url: '/pages/login/login' });
    };

    onMounted(() => {
      memoStore.fetchStats();
      memoStore.fetchCategories();
    });

    return {
      userStore, memoStore, avatarLetter, urgentCount,
      ROLE_MAP, serverUrl: SERVER_URL,
      uploadAvatar, goEditProfile, goChangePassword, goManageCategories, showAbout, handleLogout,
    };
  },
};
</script>

<style scoped>
.page { min-height: 100vh; background: #f4f6f9; padding-bottom: 60rpx; }

.profile-header {
  background: linear-gradient(145deg, #1a237e 0%, #0d47a1 100%);
  padding: 120rpx 40rpx 60rpx;
  display: flex;
  flex-direction: column;
  align-items: center;
}

.avatar-wrap { position: relative; margin-bottom: 28rpx; }

.avatar {
  width: 160rpx;
  height: 160rpx;
  border-radius: 50%;
  border: 4rpx solid rgba(255,255,255,0.5);
}

.avatar-placeholder {
  width: 160rpx;
  height: 160rpx;
  border-radius: 50%;
  background: rgba(255,255,255,0.2);
  display: flex;
  align-items: center;
  justify-content: center;
  border: 4rpx solid rgba(255,255,255,0.5);
}

.avatar-letter { font-size: 72rpx; font-weight: 700; color: #fff; }

.avatar-edit {
  position: absolute;
  bottom: 0;
  right: 0;
  width: 52rpx;
  height: 52rpx;
  background: #fff;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 28rpx;
}

.profile-name { font-size: 40rpx; font-weight: 700; color: #fff; margin-bottom: 10rpx; }
.profile-email { font-size: 26rpx; color: rgba(255,255,255,0.7); margin-bottom: 20rpx; }

.role-badge {
  font-size: 24rpx;
  color: #fff;
  background: rgba(255,255,255,0.2);
  padding: 8rpx 28rpx;
  border-radius: 30rpx;
  border: 1rpx solid rgba(255,255,255,0.3);
}

.stats-row {
  background: #fff;
  margin: 24rpx 32rpx;
  border-radius: 24rpx;
  display: flex;
  align-items: center;
  padding: 40rpx 0;
  box-shadow: 0 4rpx 20rpx rgba(0,0,0,0.06);
}

.stat-item { flex: 1; display: flex; flex-direction: column; align-items: center; gap: 8rpx; }
.stat-num { font-size: 52rpx; font-weight: 800; color: #1c1c1e; }
.stat-num.urgent { color: #ff3b30; }
.stat-label { font-size: 24rpx; color: #8e8e93; }
.stat-divider { width: 2rpx; height: 80rpx; background: #f0f0f0; }

.section { margin: 0 32rpx 32rpx; }
.section-title { font-size: 26rpx; color: #8e8e93; font-weight: 600; padding: 20rpx 0 12rpx; letter-spacing: 1rpx; }

.menu-list { background: #fff; border-radius: 24rpx; overflow: hidden; box-shadow: 0 2rpx 12rpx rgba(0,0,0,0.05); }

.menu-item {
  display: flex;
  align-items: center;
  padding: 36rpx 32rpx;
  border-bottom: 1rpx solid #f9f9f9;
}

.menu-item:last-child { border-bottom: none; }

.menu-icon { font-size: 36rpx; margin-right: 24rpx; }
.menu-label { flex: 1; font-size: 32rpx; color: #1c1c1e; }
.menu-arrow { font-size: 40rpx; color: #c7c7cc; }
.menu-version { font-size: 26rpx; color: #8e8e93; }

.logout-wrap { padding: 20rpx 32rpx; }

.logout-btn {
  width: 100%;
  height: 100rpx;
  background: #fff;
  color: #ff3b30;
  font-size: 34rpx;
  font-weight: 600;
  border-radius: 24rpx;
  border: none;
  box-shadow: 0 2rpx 12rpx rgba(0,0,0,0.06);
}
</style>
