<template>
  <view class="login-wrap">
    <view class="login-bg">
      <view class="bg-circle circle-1" />
      <view class="bg-circle circle-2" />
    </view>

    <view class="login-content">
      <view class="logo-area">
        <view class="logo-icon">
          <text class="logo-text">M</text>
        </view>
        <text class="app-name">企业备忘录</text>
        <text class="app-sub">Enterprise Memo System</text>
      </view>

      <view class="form-card">
        <view class="form-item">
          <view class="input-label">邮箱</view>
          <input
            v-model="form.email"
            class="input-field"
            type="text"
            placeholder="请输入企业邮箱"
            placeholder-class="placeholder"
            @input="clearError('email')"
          />
          <text v-if="errors.email" class="error-msg">{{ errors.email }}</text>
        </view>

        <view class="form-item" style="margin-top: 32rpx">
          <view class="input-label">密码</view>
          <view class="password-wrap">
            <input
              v-model="form.password"
              class="input-field"
              :type="showPwd ? 'text' : 'password'"
              placeholder="请输入密码"
              placeholder-class="placeholder"
              @input="clearError('password')"
            />
            <text class="eye-btn" @tap="showPwd = !showPwd">{{ showPwd ? '隐藏' : '显示' }}</text>
          </view>
          <text v-if="errors.password" class="error-msg">{{ errors.password }}</text>
        </view>

        <button class="login-btn" :loading="loading" :disabled="loading" @tap="handleLogin">
          {{ loading ? '登录中...' : '登 录' }}
        </button>

        <view class="bottom-links">
          <text class="link-text" @tap="goRegister">没有账号？立即注册</text>
        </view>
      </view>

      <text class="version-text">v1.0.0 · 企业版</text>
    </view>
  </view>
</template>

<script>
import { ref, reactive } from 'vue';
import { useUserStore } from '../../store/user';
import { apiLogin } from '../../api/auth';
import { showToast } from '../../utils/util';

export default {
  setup() {
    const userStore = useUserStore();
    const loading = ref(false);
    const showPwd = ref(false);
    const form = reactive({ email: '', password: '' });
    const errors = reactive({ email: '', password: '' });

    const validate = () => {
      let valid = true;
      if (!form.email) { errors.email = '请输入邮箱'; valid = false; }
      else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) { errors.email = '邮箱格式不正确'; valid = false; }
      if (!form.password) { errors.password = '请输入密码'; valid = false; }
      return valid;
    };

    const clearError = (field) => { errors[field] = ''; };

    const handleLogin = async () => {
      if (!validate()) return;
      loading.value = true;
      try {
        const res = await apiLogin({ email: form.email, password: form.password });
        if (res.success) {
          userStore.setTokens(res.data.access_token, res.data.refresh_token);
          userStore.setUserInfo(res.data.user);
          showToast('登录成功', 'success');
          setTimeout(() => {
            uni.switchTab({ url: '/pages/index/index' });
          }, 300);
        }
      } catch (err) {
        const msg = err?.message || '登录失败';
        showToast(msg);
      } finally {
        loading.value = false;
      }
    };

    const goRegister = () => uni.navigateTo({ url: '/pages/register/register' });

    return { form, errors, loading, showPwd, handleLogin, goRegister, clearError };
  },
};
</script>

<style scoped>
.login-wrap {
  min-height: 100vh;
  background: linear-gradient(145deg, #1a237e 0%, #0d47a1 50%, #01579b 100%);
  position: relative;
  overflow: hidden;
  display: flex;
  align-items: center;
  justify-content: center;
}

.login-bg {
  position: absolute;
  inset: 0;
  pointer-events: none;
}

.bg-circle {
  position: absolute;
  border-radius: 50%;
  opacity: 0.1;
  background: #fff;
}

.circle-1 {
  width: 600rpx;
  height: 600rpx;
  top: -200rpx;
  right: -150rpx;
}

.circle-2 {
  width: 400rpx;
  height: 400rpx;
  bottom: -100rpx;
  left: -100rpx;
}

.login-content {
  width: 100%;
  padding: 0 60rpx;
  display: flex;
  flex-direction: column;
  align-items: center;
}

.logo-area {
  display: flex;
  flex-direction: column;
  align-items: center;
  margin-bottom: 60rpx;
}

.logo-icon {
  width: 120rpx;
  height: 120rpx;
  border-radius: 30rpx;
  background: rgba(255, 255, 255, 0.2);
  display: flex;
  align-items: center;
  justify-content: center;
  margin-bottom: 24rpx;
  border: 2rpx solid rgba(255, 255, 255, 0.3);
}

.logo-text {
  font-size: 64rpx;
  font-weight: 800;
  color: #fff;
}

.app-name {
  font-size: 44rpx;
  font-weight: 700;
  color: #fff;
  letter-spacing: 4rpx;
}

.app-sub {
  font-size: 24rpx;
  color: rgba(255, 255, 255, 0.7);
  margin-top: 8rpx;
  letter-spacing: 2rpx;
}

.form-card {
  width: 100%;
  background: #fff;
  border-radius: 32rpx;
  padding: 60rpx 48rpx 48rpx;
  box-shadow: 0 20rpx 60rpx rgba(0, 0, 0, 0.15);
}

.input-label {
  font-size: 26rpx;
  font-weight: 600;
  color: #3a3a3c;
  margin-bottom: 16rpx;
}

.input-field {
  width: 100%;
  height: 96rpx;
  background: #f4f6f9;
  border-radius: 16rpx;
  padding: 0 32rpx;
  font-size: 30rpx;
  color: #1c1c1e;
  border: 2rpx solid transparent;
}

.password-wrap {
  position: relative;
}

.eye-btn {
  position: absolute;
  right: 24rpx;
  top: 50%;
  transform: translateY(-50%);
  font-size: 26rpx;
  color: #007aff;
}

.error-msg {
  font-size: 24rpx;
  color: #ff3b30;
  margin-top: 10rpx;
  display: block;
}

.login-btn {
  width: 100%;
  height: 100rpx;
  background: linear-gradient(135deg, #007aff, #0051d4);
  border-radius: 20rpx;
  font-size: 34rpx;
  font-weight: 700;
  color: #fff;
  margin-top: 56rpx;
  border: none;
  box-shadow: 0 8rpx 24rpx rgba(0, 122, 255, 0.4);
}

.bottom-links {
  display: flex;
  justify-content: center;
  margin-top: 32rpx;
}

.link-text {
  font-size: 28rpx;
  color: #007aff;
}

.version-text {
  margin-top: 48rpx;
  font-size: 24rpx;
  color: rgba(255, 255, 255, 0.5);
}

.placeholder {
  color: #c7c7cc;
}
</style>
