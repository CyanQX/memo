<template>
  <view class="page">
    <view class="header">
      <view class="header-top">
        <view class="user-greet">
          <text class="greet-text">{{ greeting }}，</text>
          <text class="user-name">{{ userStore.userInfo?.real_name || userStore.username }}</text>
        </view>
        <view class="header-actions">
          <view class="action-btn" @tap="showSearch = !showSearch">
            <text class="iconfont icon-search" />
          </view>
          <view class="action-btn" @tap="goCreate">
            <text class="add-icon">+</text>
          </view>
        </view>
      </view>

      <view v-if="showSearch" class="search-bar">
        <input
          v-model="searchKeyword"
          class="search-input"
          placeholder="搜索备忘录..."
          placeholder-class="placeholder"
          @input="onSearch"
          focus
        />
        <text v-if="searchKeyword" class="clear-btn" @tap="clearSearch">✕</text>
      </view>

      <scroll-view class="filter-tabs" scroll-x>
        <view
          v-for="tab in filterTabs"
          :key="tab.value"
          class="filter-tab"
          :class="{ active: activeFilter === tab.value }"
          @tap="setFilter(tab.value)"
        >
          {{ tab.label }}
        </view>
      </scroll-view>
    </view>

    <scroll-view
      class="memo-list"
      scroll-y
      :refresher-enabled="true"
      :refresher-triggered="refreshing"
      @refresherrefresh="onRefresh"
      @scrolltolower="loadMore"
    >
      <view v-if="memoStore.loading && !memoStore.memos.length" class="loading-wrap">
        <view class="loading-spinner" />
        <text class="loading-text">加载中...</text>
      </view>

      <view v-else-if="!memoStore.memos.length" class="empty-state">
        <text class="empty-icon">📝</text>
        <text class="empty-title">暂无备忘录</text>
        <text class="empty-sub">点击右上角 + 创建第一条备忘录</text>
      </view>

      <view v-else class="memo-groups">
        <view v-if="pinnedMemos.length" class="group-section">
          <text class="group-title">📌 已置顶</text>
          <view
            v-for="memo in pinnedMemos"
            :key="memo.id"
            class="memo-card pinned"
            @tap="goDetail(memo.id)"
            @longpress="onLongPress(memo)"
          >
            <memo-card :memo="memo" />
          </view>
        </view>

        <view class="group-section">
          <text v-if="pinnedMemos.length" class="group-title">其他备忘录</text>
          <view
            v-for="memo in normalMemos"
            :key="memo.id"
            class="memo-card"
            @tap="goDetail(memo.id)"
            @longpress="onLongPress(memo)"
          >
            <memo-card :memo="memo" />
          </view>
        </view>
      </view>

      <view v-if="memoStore.currentPage >= memoStore.totalPages && memoStore.memos.length" class="list-end">
        <text>— 已显示全部 {{ memoStore.total }} 条 —</text>
      </view>

      <view style="height: 120rpx;" />
    </scroll-view>

    <view class="fab" @tap="goCreate">
      <text class="fab-icon">+</text>
    </view>

    <uni-popup ref="actionPopup" type="bottom" safe-area>
      <view v-if="selectedMemo" class="action-sheet">
        <view class="action-title">{{ selectedMemo.title }}</view>
        <view class="action-item" @tap="goEdit(selectedMemo.id)">✏️ 编辑</view>
        <view class="action-item" @tap="togglePin(selectedMemo)">
          {{ selectedMemo.is_pinned ? '📌 取消置顶' : '📌 置顶' }}
        </view>
        <view class="action-item" @tap="archiveMemo(selectedMemo.id)">📦 归档</view>
        <view class="action-item danger" @tap="confirmDelete(selectedMemo.id)">🗑️ 删除</view>
        <view class="action-cancel" @tap="actionPopup.close()">取消</view>
      </view>
    </uni-popup>
  </view>
</template>

<script>
import { ref, computed, onMounted } from 'vue';
import { useUserStore } from '../../store/user';
import { useMemoStore } from '../../store/memo';
import { apiUpdateMemo } from '../../api/memo';
import { showToast, showModal, debounce } from '../../utils/util';
import MemoCard from './MemoCard.vue';

export default {
  components: { MemoCard },
  setup() {
    const userStore = useUserStore();
    const memoStore = useMemoStore();
    const refreshing = ref(false);
    const showSearch = ref(false);
    const searchKeyword = ref('');
    const activeFilter = ref('all');
    const selectedMemo = ref(null);
    const actionPopup = ref(null);

    const greeting = computed(() => {
      const h = new Date().getHours();
      if (h < 12) return '早上好';
      if (h < 18) return '下午好';
      return '晚上好';
    });

    const filterTabs = [
      { label: '全部', value: 'all' },
      { label: '紧急', value: 'urgent' },
      { label: '高优先', value: 'high' },
      { label: '中等', value: 'medium' },
      { label: '低优先', value: 'low' },
    ];

    const pinnedMemos = computed(() => memoStore.memos.filter((m) => m.is_pinned === 1));
    const normalMemos = computed(() => memoStore.memos.filter((m) => m.is_pinned !== 1));

    const setFilter = (val) => {
      activeFilter.value = val;
      memoStore.setFilter('priority', val === 'all' ? null : val);
      memoStore.fetchMemos(1);
    };

    const onSearch = debounce(() => {
      memoStore.setFilter('keyword', searchKeyword.value);
      memoStore.fetchMemos(1);
    }, 400);

    const clearSearch = () => {
      searchKeyword.value = '';
      memoStore.setFilter('keyword', '');
      memoStore.fetchMemos(1);
    };

    const onRefresh = async () => {
      refreshing.value = true;
      await memoStore.fetchMemos(1);
      refreshing.value = false;
    };

    const loadMore = async () => {
      if (memoStore.currentPage < memoStore.totalPages && !memoStore.loading) {
        await memoStore.fetchMemos(memoStore.currentPage + 1, true);
      }
    };

    const goCreate = () => uni.navigateTo({ url: '/pages/memo/create' });
    const goDetail = (id) => uni.navigateTo({ url: `/pages/memo/detail?id=${id}` });
    const goEdit = (id) => {
      actionPopup.value?.close();
      uni.navigateTo({ url: `/pages/memo/edit?id=${id}` });
    };

    const onLongPress = (memo) => {
      selectedMemo.value = memo;
      actionPopup.value?.open();
    };

    const togglePin = async (memo) => {
      actionPopup.value?.close();
      try {
        const res = await apiUpdateMemo(memo.id, { is_pinned: memo.is_pinned ? 0 : 1 });
        if (res.success) {
          memoStore.updateMemoInList(memo.id, { is_pinned: memo.is_pinned ? 0 : 1 });
          showToast(memo.is_pinned ? '已取消置顶' : '已置顶');
        }
      } catch {}
    };

    const archiveMemo = async (id) => {
      actionPopup.value?.close();
      try {
        const res = await apiUpdateMemo(id, { status: 'archived' });
        if (res.success) {
          memoStore.memos = memoStore.memos.filter((m) => m.id !== id);
          showToast('已归档');
        }
      } catch {}
    };

    const confirmDelete = async (id) => {
      actionPopup.value?.close();
      const confirmed = await showModal('确认删除', '此操作将删除该备忘录，确定吗？');
      if (confirmed) {
        const ok = await memoStore.deleteMemoById(id);
        if (ok) showToast('已删除');
      }
    };

    onMounted(() => {
      memoStore.fetchMemos(1);
      memoStore.fetchCategories();
    });

    return {
      userStore, memoStore, refreshing, showSearch, searchKeyword,
      activeFilter, filterTabs, selectedMemo, actionPopup,
      greeting, pinnedMemos, normalMemos,
      setFilter, onSearch, clearSearch, onRefresh, loadMore,
      goCreate, goDetail, goEdit, onLongPress, togglePin, archiveMemo, confirmDelete,
    };
  },
};
</script>

<style scoped>
.page { min-height: 100vh; background: #f4f6f9; }

.header {
  background: #fff;
  padding: 100rpx 40rpx 0;
  box-shadow: 0 2rpx 12rpx rgba(0,0,0,0.06);
}

.header-top {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding-bottom: 32rpx;
}

.greet-text { font-size: 32rpx; color: #8e8e93; }
.user-name { font-size: 36rpx; font-weight: 700; color: #1c1c1e; }

.header-actions { display: flex; gap: 16rpx; }

.action-btn {
  width: 72rpx; height: 72rpx;
  background: #f4f6f9; border-radius: 18rpx;
  display: flex; align-items: center; justify-content: center;
}

.add-icon { font-size: 44rpx; font-weight: 300; color: #007aff; line-height: 1; }

.search-bar {
  position: relative;
  margin-bottom: 24rpx;
}

.search-input {
  width: 100%;
  height: 80rpx;
  background: #f4f6f9;
  border-radius: 20rpx;
  padding: 0 80rpx 0 28rpx;
  font-size: 28rpx;
}

.clear-btn {
  position: absolute;
  right: 24rpx;
  top: 50%;
  transform: translateY(-50%);
  font-size: 28rpx;
  color: #c7c7cc;
}

.filter-tabs {
  display: flex;
  white-space: nowrap;
  padding-bottom: 24rpx;
}

.filter-tab {
  display: inline-block;
  padding: 12rpx 32rpx;
  border-radius: 40rpx;
  font-size: 26rpx;
  color: #8e8e93;
  background: #f4f6f9;
  margin-right: 16rpx;
  white-space: nowrap;
}

.filter-tab.active {
  background: #007aff;
  color: #fff;
  font-weight: 600;
}

.memo-list { height: calc(100vh - 280rpx); }

.loading-wrap {
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 120rpx 0;
}

.loading-spinner {
  width: 60rpx;
  height: 60rpx;
  border: 4rpx solid #e5e5ea;
  border-top-color: #007aff;
  border-radius: 50%;
  animation: spin 0.8s linear infinite;
}

@keyframes spin { to { transform: rotate(360deg); } }

.loading-text { margin-top: 24rpx; font-size: 28rpx; color: #8e8e93; }

.empty-state {
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 160rpx 0;
}

.empty-icon { font-size: 100rpx; }
.empty-title { font-size: 36rpx; font-weight: 600; color: #3a3a3c; margin-top: 32rpx; }
.empty-sub { font-size: 26rpx; color: #8e8e93; margin-top: 16rpx; }

.memo-groups { padding: 24rpx 32rpx; }
.group-section { margin-bottom: 8rpx; }
.group-title { font-size: 24rpx; color: #8e8e93; font-weight: 600; padding: 16rpx 0; display: block; letter-spacing: 1rpx; }
.memo-card { margin-bottom: 20rpx; }

.list-end { text-align: center; padding: 40rpx; font-size: 24rpx; color: #c7c7cc; }

.fab {
  position: fixed;
  right: 48rpx;
  bottom: 160rpx;
  width: 108rpx;
  height: 108rpx;
  background: linear-gradient(135deg, #007aff, #0051d4);
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0 8rpx 32rpx rgba(0, 122, 255, 0.5);
  z-index: 100;
}

.fab-icon { font-size: 60rpx; color: #fff; font-weight: 300; line-height: 1; }

.action-sheet {
  background: #fff;
  border-radius: 32rpx 32rpx 0 0;
  padding: 0 0 40rpx;
  padding-bottom: calc(40rpx + env(safe-area-inset-bottom));
}

.action-title {
  padding: 40rpx;
  font-size: 28rpx;
  color: #8e8e93;
  text-align: center;
  border-bottom: 1rpx solid #f0f0f0;
}

.action-item {
  padding: 36rpx 48rpx;
  font-size: 32rpx;
  color: #1c1c1e;
  border-bottom: 1rpx solid #f0f0f0;
}

.action-item.danger { color: #ff3b30; }

.action-cancel {
  padding: 36rpx;
  text-align: center;
  font-size: 32rpx;
  color: #007aff;
  font-weight: 600;
  margin-top: 16rpx;
}

.placeholder { color: #c7c7cc; }
</style>
