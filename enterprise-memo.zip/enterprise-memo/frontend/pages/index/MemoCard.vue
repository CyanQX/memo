<template>
  <view class="card" :style="{ borderLeftColor: priorityColor }">
    <view class="card-header">
      <text class="card-title" :numberOfLines="1">{{ memo.title }}</text>
      <view class="priority-badge" :style="{ backgroundColor: priorityColor + '20', color: priorityColor }">
        {{ priorityLabel }}
      </view>
    </view>

    <text v-if="memo.content_preview" class="card-content">{{ memo.content_preview }}</text>

    <view class="card-footer">
      <view class="card-meta">
        <view v-if="memo.category_name" class="category-tag" :style="{ color: memo.category_color }">
          {{ memo.category_name }}
        </view>
        <view class="tags-list">
          <text v-for="tag in (memo.tags || []).slice(0, 2)" :key="tag.id" class="tag">
            #{{ tag.name }}
          </text>
        </view>
      </view>
      <text class="card-time">{{ formatDate(memo.updated_at) }}</text>
    </view>
  </view>
</template>

<script>
import { computed } from 'vue';
import { PRIORITY_MAP, formatDate } from '../../utils/util';

export default {
  props: {
    memo: { type: Object, required: true },
  },
  setup(props) {
    const priorityColor = computed(() => PRIORITY_MAP[props.memo.priority]?.color || '#8e8e93');
    const priorityLabel = computed(() => PRIORITY_MAP[props.memo.priority]?.label || '');
    return { priorityColor, priorityLabel, formatDate };
  },
};
</script>

<style scoped>
.card {
  background: #fff;
  border-radius: 20rpx;
  padding: 32rpx;
  box-shadow: 0 2rpx 16rpx rgba(0,0,0,0.06);
  border-left: 6rpx solid #e5e5ea;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 16rpx;
}

.card-title {
  flex: 1;
  font-size: 32rpx;
  font-weight: 600;
  color: #1c1c1e;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  margin-right: 16rpx;
}

.priority-badge {
  font-size: 22rpx;
  font-weight: 600;
  padding: 4rpx 16rpx;
  border-radius: 20rpx;
  flex-shrink: 0;
}

.card-content {
  font-size: 26rpx;
  color: #636366;
  line-height: 1.6;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
  margin-bottom: 24rpx;
}

.card-footer {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.card-meta { display: flex; align-items: center; gap: 12rpx; flex-wrap: wrap; }

.category-tag {
  font-size: 22rpx;
  font-weight: 600;
  padding: 4rpx 14rpx;
  border-radius: 12rpx;
  background: currentColor;
  color: inherit;
  opacity: 0.8;
}

.tags-list { display: flex; gap: 8rpx; }

.tag {
  font-size: 22rpx;
  color: #8e8e93;
}

.card-time {
  font-size: 22rpx;
  color: #c7c7cc;
  flex-shrink: 0;
}
</style>
