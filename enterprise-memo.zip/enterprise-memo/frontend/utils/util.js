export const formatDate = (dateStr, format = 'YYYY-MM-DD HH:mm') => {
  if (!dateStr) return '';
  const d = new Date(dateStr);
  const now = new Date();
  const diff = now - d;

  if (diff < 60000) return '刚刚';
  if (diff < 3600000) return `${Math.floor(diff / 60000)}分钟前`;
  if (diff < 86400000) return `${Math.floor(diff / 3600000)}小时前`;
  if (diff < 604800000) return `${Math.floor(diff / 86400000)}天前`;

  const pad = (n) => String(n).padStart(2, '0');
  return format
    .replace('YYYY', d.getFullYear())
    .replace('MM', pad(d.getMonth() + 1))
    .replace('DD', pad(d.getDate()))
    .replace('HH', pad(d.getHours()))
    .replace('mm', pad(d.getMinutes()));
};

export const truncate = (str, len = 80) => {
  if (!str) return '';
  return str.length > len ? str.substring(0, len) + '...' : str;
};

export const PRIORITY_MAP = {
  low: { label: '低', color: '#8E8E93' },
  medium: { label: '中', color: '#007AFF' },
  high: { label: '高', color: '#FF9500' },
  urgent: { label: '紧急', color: '#FF3B30' },
};

export const ROLE_MAP = {
  super_admin: '超级管理员',
  admin: '管理员',
  manager: '主管',
  user: '普通用户',
};

export const debounce = (fn, delay = 300) => {
  let timer;
  return (...args) => {
    clearTimeout(timer);
    timer = setTimeout(() => fn.apply(this, args), delay);
  };
};

export const showToast = (title, icon = 'none') => {
  uni.showToast({ title, icon, duration: 2000 });
};

export const showModal = (title, content) => {
  return new Promise((resolve) => {
    uni.showModal({
      title,
      content,
      success: (res) => resolve(res.confirm),
    });
  });
};

export const navigateTo = (url) => uni.navigateTo({ url });

export const redirectTo = (url) => uni.redirectTo({ url });

export const reLaunch = (url) => uni.reLaunch({ url });
