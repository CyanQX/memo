import { createPinia } from 'pinia';

const pinia = createPinia();

export default pinia;

export { useUserStore } from './user';
export { useMemoStore } from './memo';
