import { defineStore } from 'pinia';
import { apiGetMemos, apiGetMemoStats, apiDeleteMemo } from '../api/memo';
import { apiGetCategories } from '../api/category';

export const useMemoStore = defineStore('memo', {
  state: () => ({
    memos: [],
    total: 0,
    currentPage: 1,
    totalPages: 1,
    loading: false,
    categories: [],
    stats: null,
    filters: {
      status: 'active',
      keyword: '',
      category_id: null,
      priority: null,
      sort_by: 'updated_at',
      sort_order: 'desc',
    },
  }),

  getters: {
    pinnedMemos: (state) => state.memos.filter((m) => m.is_pinned === 1),
    normalMemos: (state) => state.memos.filter((m) => m.is_pinned !== 1),
    categoryById: (state) => (id) => state.categories.find((c) => c.id === id),
  },

  actions: {
    async fetchMemos(page = 1, append = false) {
      if (this.loading) return;
      this.loading = true;
      try {
        const params = {
          page,
          limit: 20,
          ...this.filters,
        };
        Object.keys(params).forEach((k) => {
          if (params[k] === null || params[k] === '') delete params[k];
        });

        const res = await apiGetMemos(params);
        if (res.success) {
          if (append) {
            this.memos = [...this.memos, ...res.data];
          } else {
            this.memos = res.data;
          }
          this.total = res.pagination.total;
          this.currentPage = res.pagination.page;
          this.totalPages = res.pagination.total_pages;
        }
      } catch (err) {
        console.error('Fetch memos failed:', err);
      } finally {
        this.loading = false;
      }
    },

    async fetchCategories() {
      try {
        const res = await apiGetCategories();
        if (res.success) this.categories = res.data;
      } catch (err) {
        console.error('Fetch categories failed:', err);
      }
    },

    async fetchStats() {
      try {
        const res = await apiGetMemoStats();
        if (res.success) this.stats = res.data;
      } catch (err) {
        console.error('Fetch stats failed:', err);
      }
    },

    async deleteMemoById(id) {
      try {
        const res = await apiDeleteMemo(id);
        if (res.success) {
          this.memos = this.memos.filter((m) => m.id !== id);
          this.total -= 1;
        }
        return res.success;
      } catch {
        return false;
      }
    },

    setFilter(key, value) {
      this.filters[key] = value;
    },

    resetFilters() {
      this.filters = {
        status: 'active',
        keyword: '',
        category_id: null,
        priority: null,
        sort_by: 'updated_at',
        sort_order: 'desc',
      };
    },

    updateMemoInList(id, updates) {
      const index = this.memos.findIndex((m) => m.id === id);
      if (index !== -1) {
        this.memos[index] = { ...this.memos[index], ...updates };
      }
    },
  },
});
