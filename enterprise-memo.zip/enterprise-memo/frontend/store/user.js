import { defineStore } from 'pinia';
import { apiGetProfile, apiLogout } from '../api/auth';

export const useUserStore = defineStore('user', {
  state: () => ({
    userInfo: uni.getStorageSync('user_info') ? JSON.parse(uni.getStorageSync('user_info')) : null,
    isLoggedIn: !!uni.getStorageSync('access_token'),
  }),

  getters: {
    userId: (state) => state.userInfo?.id,
    username: (state) => state.userInfo?.username || '',
    avatar: (state) => state.userInfo?.avatar || '',
    role: (state) => state.userInfo?.role || 'user',
    isAdmin: (state) => ['super_admin', 'admin'].includes(state.userInfo?.role),
  },

  actions: {
    setTokens(accessToken, refreshToken) {
      uni.setStorageSync('access_token', accessToken);
      if (refreshToken) uni.setStorageSync('refresh_token', refreshToken);
      this.isLoggedIn = true;
    },

    setUserInfo(user) {
      this.userInfo = user;
      uni.setStorageSync('user_info', JSON.stringify(user));
    },

    async fetchProfile() {
      try {
        const res = await apiGetProfile();
        if (res.success) {
          this.setUserInfo(res.data);
        }
      } catch (err) {
        console.error('Fetch profile failed:', err);
      }
    },

    async logout() {
      try {
        await apiLogout();
      } catch {}
      this.clearAuth();
    },

    clearAuth() {
      this.userInfo = null;
      this.isLoggedIn = false;
      uni.removeStorageSync('access_token');
      uni.removeStorageSync('refresh_token');
      uni.removeStorageSync('user_info');
    },
  },
});
